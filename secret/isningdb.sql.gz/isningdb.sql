# WordPress MySQL database migration
#
# Generated: Thursday 18. August 2022 05:39 UTC
# Hostname: localhost
# Database: `isningdb`
# URL: //localhost/isning
# Path: C:\\xampp\\htdocs\\isning
# Tables: it_commentmeta, it_comments, it_links, it_options, it_postmeta, it_posts, it_smush_dir_images, it_term_relationships, it_term_taxonomy, it_termmeta, it_terms, it_usermeta, it_users
# Table Prefix: it_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `it_commentmeta`
#

DROP TABLE IF EXISTS `it_commentmeta`;


#
# Table structure of table `it_commentmeta`
#

CREATE TABLE `it_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_commentmeta`
#

#
# End of data contents of table `it_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `it_comments`
#

DROP TABLE IF EXISTS `it_comments`;


#
# Table structure of table `it_comments`
#

CREATE TABLE `it_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_comments`
#
INSERT INTO `it_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-08-14 02:32:59', '2022-08-14 02:32:59', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `it_comments`
# --------------------------------------------------------



#
# Delete any existing table `it_links`
#

DROP TABLE IF EXISTS `it_links`;


#
# Table structure of table `it_links`
#

CREATE TABLE `it_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_links`
#

#
# End of data contents of table `it_links`
# --------------------------------------------------------



#
# Delete any existing table `it_options`
#

DROP TABLE IF EXISTS `it_options`;


#
# Table structure of table `it_options`
#

CREATE TABLE `it_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1471 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_options`
#
INSERT INTO `it_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/isning', 'yes'),
(2, 'home', 'http://localhost/isning', 'yes'),
(3, 'blogname', 'ISNING TEST', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jenniercruz90@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:95:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";i:3;s:23:"wp-smushit/wp-smush.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'isning_theme', 'yes'),
(41, 'stylesheet', 'isning_theme', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1675996379', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'it_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `it_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:9:{i:1660804380;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1660833180;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1660833192;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1660867200;a:1:{s:22:"wdev_logger_clear_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1660876379;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1660876392;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1660876393;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1661135579;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(122, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1660447532;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(125, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:24:"SSL verification failed.";}}', 'yes'),
(140, 'can_compress_scripts', '1', 'no'),
(151, 'recently_activated', 'a:0:{}', 'yes'),
(158, 'cptui_new_install', 'false', 'yes'),
(161, 'finished_updating_comment_type', '1', 'yes'),
(166, 'acf_version', '5.9.9', 'yes'),
(205, 'current_theme', 'isning_theme', 'yes'),
(206, 'theme_mods_isning_theme', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:4;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(207, 'theme_switched', '', 'yes'),
(434, 'wp-smush-settings', 'a:24:{s:4:"auto";b:1;s:5:"lossy";b:0;s:10:"strip_exif";b:1;s:6:"resize";b:0;s:9:"detection";b:0;s:8:"original";b:0;s:6:"backup";b:0;s:8:"no_scale";b:0;s:10:"png_to_jpg";b:0;s:7:"nextgen";b:0;s:2:"s3";b:0;s:9:"gutenberg";b:0;s:10:"js_builder";b:0;s:5:"gform";b:0;s:3:"cdn";b:0;s:11:"auto_resize";b:0;s:4:"webp";b:1;s:5:"usage";b:0;s:17:"accessible_colors";b:0;s:9:"keep_data";b:1;s:9:"lazy_load";b:0;s:17:"background_images";b:1;s:16:"rest_api_support";b:0;s:8:"webp_mod";b:0;}', 'yes'),
(435, 'wp-smush-install-type', 'existing', 'no'),
(436, 'wp-smush-version', '3.10.3', 'no'),
(439, 'wdev-frash', 'a:3:{s:7:"plugins";a:1:{s:23:"wp-smushit/wp-smush.php";i:1660613799;}s:5:"queue";a:2:{s:32:"7de3619981caadc55f30a002bfb299f6";a:4:{s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:4:"type";s:5:"email";s:7:"show_at";i:1660613799;s:6:"sticky";b:1;}s:32:"fc50097023d0d34c5a66f6cddcf77694";a:3:{s:6:"plugin";s:23:"wp-smushit/wp-smush.php";s:4:"type";s:4:"rate";s:7:"show_at";i:1661218599;}}s:4:"done";a:0:{}}', 'no'),
(440, 'wpmudev_recommended_plugins_registered', 'a:1:{s:23:"wp-smushit/wp-smush.php";a:1:{s:13:"registered_at";i:1660613799;}}', 'no'),
(683, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(1320, 'options_sub_footer_image', '27', 'no'),
(1321, '_options_sub_footer_image', 'field_62fdc01046971', 'no'),
(1322, 'options_site_copyright', 'Copyright SoCal Radiology, 2022. All Rights Reserved', 'no'),
(1323, '_options_site_copyright', 'field_62fdc02346972', 'no'),
(1333, 'options_footer_logo', '26', 'no'),
(1334, '_options_footer_logo', 'field_62fdc243cae00', 'no'),
(1335, 'options_footer_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, deleniti autem aut sit placeat aspernatur inventore quibusdam maiores voluptates commodi dolores corporis architecto quia impedit? Accusantium, placeat asperiores. Qui, laboriosam.', 'no'),
(1336, '_options_footer_text', 'field_62fdc263cae01', 'no'),
(1363, 'options_site_logo', '25', 'no'),
(1364, '_options_site_logo', 'field_62fdc5514827f', 'no'),
(1372, 'options_open_hours_0_open_day', 'Monday', 'no'),
(1373, '_options_open_hours_0_open_day', 'field_62fdc61af8c33', 'no'),
(1374, 'options_open_hours_0_open_hour', '10am - 8pm', 'no'),
(1375, '_options_open_hours_0_open_hour', 'field_62fdc633f8c34', 'no'),
(1376, 'options_open_hours_1_open_day', 'Thuesday', 'no'),
(1377, '_options_open_hours_1_open_day', 'field_62fdc61af8c33', 'no'),
(1378, 'options_open_hours_1_open_hour', '10am - 8pm', 'no'),
(1379, '_options_open_hours_1_open_hour', 'field_62fdc633f8c34', 'no'),
(1380, 'options_open_hours_2_open_day', 'Wednesday', 'no'),
(1381, '_options_open_hours_2_open_day', 'field_62fdc61af8c33', 'no'),
(1382, 'options_open_hours_2_open_hour', '10am - 8pm', 'no'),
(1383, '_options_open_hours_2_open_hour', 'field_62fdc633f8c34', 'no'),
(1384, 'options_open_hours_3_open_day', 'Thursday', 'no'),
(1385, '_options_open_hours_3_open_day', 'field_62fdc61af8c33', 'no'),
(1386, 'options_open_hours_3_open_hour', '10am - 8pm', 'no'),
(1387, '_options_open_hours_3_open_hour', 'field_62fdc633f8c34', 'no'),
(1388, 'options_open_hours_4_open_day', 'Friday', 'no'),
(1389, '_options_open_hours_4_open_day', 'field_62fdc61af8c33', 'no'),
(1390, 'options_open_hours_4_open_hour', '10am - 8pm', 'no'),
(1391, '_options_open_hours_4_open_hour', 'field_62fdc633f8c34', 'no'),
(1392, 'options_open_hours_5_open_day', 'Saturday, Sunday	', 'no'),
(1393, '_options_open_hours_5_open_day', 'field_62fdc61af8c33', 'no'),
(1394, 'options_open_hours_5_open_hour', '10am - 6pm', 'no'),
(1395, '_options_open_hours_5_open_hour', 'field_62fdc633f8c34', 'no'),
(1396, 'options_open_hours', '6', 'no'),
(1397, '_options_open_hours', 'field_62fdc5eaf8c32', 'no'),
(1436, 'category_children', 'a:0:{}', 'yes'),
(1470, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1660801163;}', 'no') ;

#
# End of data contents of table `it_options`
# --------------------------------------------------------



#
# Delete any existing table `it_postmeta`
#

DROP TABLE IF EXISTS `it_postmeta`;


#
# Table structure of table `it_postmeta`
#

CREATE TABLE `it_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1098 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_postmeta`
#
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 6, '_edit_lock', '1660801112:1'),
(6, 6, '_wp_page_template', 'page-home.php'),
(9, 13, '_wp_attached_file', '2022/08/services.webp'),
(10, 13, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:732;s:6:"height";i:549;s:4:"file";s:21:"2022/08/services.webp";s:8:"filesize";i:30736;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 14, '_wp_attached_file', '2022/08/smile.jpg'),
(12, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:990;s:4:"file";s:17:"2022/08/smile.jpg";s:8:"filesize";s:6:"319399";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(13, 14, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";d:2.995939248400903;s:5:"bytes";i:9569;s:11:"size_before";i:319399;s:10:"size_after";i:309830;s:4:"time";d:0.14;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";i:3;s:5:"bytes";i:9569;s:11:"size_before";i:319399;s:10:"size_after";i:309830;s:4:"time";d:0.14;}}}'),
(14, 15, '_wp_attached_file', '2022/08/ct-scan.jpg'),
(15, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2560;s:6:"height";i:1581;s:4:"file";s:19:"2022/08/ct-scan.jpg";s:8:"filesize";s:6:"372022";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(16, 15, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";i:0;s:5:"bytes";i:0;s:11:"size_before";i:372022;s:10:"size_after";i:372022;s:4:"time";d:0.2;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";i:0;s:5:"bytes";i:0;s:11:"size_before";i:372022;s:10:"size_after";i:372022;s:4:"time";d:0.2;}}}'),
(17, 16, '_wp_attached_file', '2022/08/new-ct.jpg'),
(18, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2500;s:6:"height";i:1754;s:4:"file";s:18:"2022/08/new-ct.jpg";s:8:"filesize";s:6:"438979";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(19, 16, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";i:0;s:5:"bytes";i:0;s:11:"size_before";i:438979;s:10:"size_after";i:438979;s:4:"time";d:0.29;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";i:0;s:5:"bytes";i:0;s:11:"size_before";i:438979;s:10:"size_after";i:438979;s:4:"time";d:0.29;}}}'),
(20, 17, '_wp_attached_file', '2022/08/ct-scan-2.jpg'),
(21, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1408;s:6:"height";i:1056;s:4:"file";s:21:"2022/08/ct-scan-2.jpg";s:8:"filesize";s:5:"61527";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(22, 17, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";d:2.043005509776196;s:5:"bytes";i:1257;s:11:"size_before";i:61527;s:10:"size_after";i:60270;s:4:"time";d:0.04;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";d:2.04;s:5:"bytes";i:1257;s:11:"size_before";i:61527;s:10:"size_after";i:60270;s:4:"time";d:0.04;}}}'),
(23, 18, '_menu_item_type', 'post_type'),
(24, 18, '_menu_item_menu_item_parent', '0'),
(25, 18, '_menu_item_object_id', '6'),
(26, 18, '_menu_item_object', 'page'),
(27, 18, '_menu_item_target', ''),
(28, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(29, 18, '_menu_item_xfn', ''),
(30, 18, '_menu_item_url', ''),
(32, 19, '_menu_item_type', 'post_type'),
(33, 19, '_menu_item_menu_item_parent', '0'),
(34, 19, '_menu_item_object_id', '2'),
(35, 19, '_menu_item_object', 'page'),
(36, 19, '_menu_item_target', ''),
(37, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(38, 19, '_menu_item_xfn', ''),
(39, 19, '_menu_item_url', ''),
(40, 19, '_menu_item_orphaned', '1660628823'),
(41, 20, '_menu_item_type', 'custom'),
(42, 20, '_menu_item_menu_item_parent', '0'),
(43, 20, '_menu_item_object_id', '20'),
(44, 20, '_menu_item_object', 'custom'),
(45, 20, '_menu_item_target', ''),
(46, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(47, 20, '_menu_item_xfn', ''),
(48, 20, '_menu_item_url', '#'),
(50, 21, '_menu_item_type', 'custom'),
(51, 21, '_menu_item_menu_item_parent', '0'),
(52, 21, '_menu_item_object_id', '21'),
(53, 21, '_menu_item_object', 'custom'),
(54, 21, '_menu_item_target', ''),
(55, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(56, 21, '_menu_item_xfn', ''),
(57, 21, '_menu_item_url', '#'),
(59, 22, '_menu_item_type', 'custom'),
(60, 22, '_menu_item_menu_item_parent', '0'),
(61, 22, '_menu_item_object_id', '22'),
(62, 22, '_menu_item_object', 'custom'),
(63, 22, '_menu_item_target', ''),
(64, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(65, 22, '_menu_item_xfn', ''),
(66, 22, '_menu_item_url', '#'),
(68, 23, '_menu_item_type', 'custom'),
(69, 23, '_menu_item_menu_item_parent', '0'),
(70, 23, '_menu_item_object_id', '23'),
(71, 23, '_menu_item_object', 'custom'),
(72, 23, '_menu_item_target', ''),
(73, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(74, 23, '_menu_item_xfn', ''),
(75, 23, '_menu_item_url', '#'),
(77, 24, '_menu_item_type', 'custom'),
(78, 24, '_menu_item_menu_item_parent', '0'),
(79, 24, '_menu_item_object_id', '24'),
(80, 24, '_menu_item_object', 'custom'),
(81, 24, '_menu_item_target', ''),
(82, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(83, 24, '_menu_item_xfn', ''),
(84, 24, '_menu_item_url', '#'),
(86, 25, '_wp_attached_file', '2022/08/logo.jpg'),
(87, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:132;s:6:"height";i:57;s:4:"file";s:16:"2022/08/logo.jpg";s:8:"filesize";s:4:"4660";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(88, 25, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";d:8.905579399141631;s:5:"bytes";i:415;s:11:"size_before";i:4660;s:10:"size_after";i:4245;s:4:"time";d:0.01;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";d:8.91;s:5:"bytes";i:415;s:11:"size_before";i:4660;s:10:"size_after";i:4245;s:4:"time";d:0.01;}}}'),
(89, 26, '_wp_attached_file', '2022/08/logo-dark.jpg'),
(90, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:105;s:6:"height";i:33;s:4:"file";s:21:"2022/08/logo-dark.jpg";s:8:"filesize";s:4:"3014";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(91, 26, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";d:7.531519575315196;s:5:"bytes";i:227;s:11:"size_before";i:3014;s:10:"size_after";i:2787;s:4:"time";d:0.01;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";d:7.53;s:5:"bytes";i:227;s:11:"size_before";i:3014;s:10:"size_after";i:2787;s:4:"time";d:0.01;}}}'),
(92, 27, '_wp_attached_file', '2022/08/logo-isning-dark.jpg'),
(93, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:109;s:6:"height";i:40;s:4:"file";s:28:"2022/08/logo-isning-dark.jpg";s:8:"filesize";s:4:"3679";s:10:"image_meta";a:11:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";}}'),
(94, 27, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:7:"percent";d:12.802391954335418;s:5:"bytes";i:471;s:11:"size_before";i:3679;s:10:"size_after";i:3208;s:4:"time";d:0.01;s:11:"api_version";s:3:"1.0";s:5:"lossy";b:0;s:9:"keep_exif";i:0;}s:5:"sizes";a:1:{s:4:"full";O:8:"stdClass":5:{s:7:"percent";d:12.8;s:5:"bytes";i:471;s:11:"size_before";i:3679;s:10:"size_after";i:3208;s:4:"time";d:0.01;}}}'),
(95, 28, '_edit_last', '1'),
(96, 28, '_edit_lock', '1660796493:1'),
(97, 6, '_edit_last', '1'),
(98, 6, 'background_image', '17'),
(99, 6, '_background_image', 'field_62fd648144774'),
(100, 6, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(101, 6, '_banner_title', 'field_62fd64db44775'),
(102, 6, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(103, 6, '_benner_text', 'field_62fd64f944776'),
(104, 33, 'background_image', '17'),
(105, 33, '_background_image', 'field_62fd648144774'),
(106, 33, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(107, 33, '_banner_title', 'field_62fd64db44775'),
(108, 33, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(109, 33, '_benner_text', 'field_62fd64f944776'),
(110, 6, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(111, 6, '_banner_text', 'field_62fd64f944776'),
(112, 34, 'background_image', '17'),
(113, 34, '_background_image', 'field_62fd648144774'),
(114, 34, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(115, 34, '_banner_title', 'field_62fd64db44775'),
(116, 34, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(117, 34, '_benner_text', 'field_62fd64f944776'),
(118, 34, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(119, 34, '_banner_text', 'field_62fd64f944776'),
(120, 35, 'background_image', '17'),
(121, 35, '_background_image', 'field_62fd648144774'),
(122, 35, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(123, 35, '_banner_title', 'field_62fd64db44775'),
(124, 35, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(125, 35, '_benner_text', 'field_62fd64f944776'),
(126, 35, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(127, 35, '_banner_text', 'field_62fd64f944776'),
(128, 6, 'learn_button_button_text', 'LEARN MORE'),
(129, 6, '_learn_button_button_text', 'field_62fd9855e32b2'),
(130, 6, 'learn_button_button_link', 'https://isning.com/'),
(131, 6, '_learn_button_button_link', 'field_62fd9871e32b3'),
(132, 6, 'learn_button', ''),
(133, 6, '_learn_button', 'field_62fd982ce32b1'),
(134, 39, 'background_image', '17'),
(135, 39, '_background_image', 'field_62fd648144774'),
(136, 39, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(137, 39, '_banner_title', 'field_62fd64db44775'),
(138, 39, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(139, 39, '_benner_text', 'field_62fd64f944776'),
(140, 39, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(141, 39, '_banner_text', 'field_62fd64f944776'),
(142, 39, 'learn_button_button_text', 'LEARN MORE'),
(143, 39, '_learn_button_button_text', 'field_62fd9855e32b2'),
(144, 39, 'learn_button_button_link', 'https://isning.com/'),
(145, 39, '_learn_button_button_link', 'field_62fd9871e32b3'),
(146, 39, 'learn_button', ''),
(147, 39, '_learn_button', 'field_62fd982ce32b1'),
(148, 6, 'call_button_button_text', '(888) 480-9996'),
(149, 6, '_call_button_button_text', 'field_62fd9b16f58b1'),
(150, 6, 'call_button_phone_number', '8884809996'),
(151, 6, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(152, 6, 'call_button', ''),
(153, 6, '_call_button', 'field_62fd9aecf58b0'),
(154, 43, 'background_image', '17'),
(155, 43, '_background_image', 'field_62fd648144774'),
(156, 43, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(157, 43, '_banner_title', 'field_62fd64db44775'),
(158, 43, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(159, 43, '_benner_text', 'field_62fd64f944776'),
(160, 43, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(161, 43, '_banner_text', 'field_62fd64f944776'),
(162, 43, 'learn_button_button_text', 'LEARN MORE'),
(163, 43, '_learn_button_button_text', 'field_62fd9855e32b2'),
(164, 43, 'learn_button_button_link', 'https://isning.com/'),
(165, 43, '_learn_button_button_link', 'field_62fd9871e32b3'),
(166, 43, 'learn_button', ''),
(167, 43, '_learn_button', 'field_62fd982ce32b1'),
(168, 43, 'call_button_button_text', '(888) 480-9996'),
(169, 43, '_call_button_button_text', 'field_62fd9b16f58b1'),
(170, 43, 'call_button_phone_number', '8884809996'),
(171, 43, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(172, 43, 'call_button', ''),
(173, 43, '_call_button', 'field_62fd9aecf58b0'),
(174, 44, 'background_image', '17'),
(175, 44, '_background_image', 'field_62fd648144774'),
(176, 44, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(177, 44, '_banner_title', 'field_62fd64db44775'),
(178, 44, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(179, 44, '_benner_text', 'field_62fd64f944776'),
(180, 44, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(181, 44, '_banner_text', 'field_62fd64f944776'),
(182, 44, 'learn_button_button_text', 'LEARN MORE'),
(183, 44, '_learn_button_button_text', 'field_62fd9855e32b2'),
(184, 44, 'learn_button_button_link', 'https://isning.com/'),
(185, 44, '_learn_button_button_link', 'field_62fd9871e32b3'),
(186, 44, 'learn_button', ''),
(187, 44, '_learn_button', 'field_62fd982ce32b1'),
(188, 44, 'call_button_button_text', '(888) 480-9996'),
(189, 44, '_call_button_button_text', 'field_62fd9b16f58b1'),
(190, 44, 'call_button_phone_number', '8884809996'),
(191, 44, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(192, 44, 'call_button', ''),
(193, 44, '_call_button', 'field_62fd9aecf58b0'),
(194, 6, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(195, 6, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(196, 6, 'benefits_0_benefit_text', 'Best Prices'),
(197, 6, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(198, 6, 'benefits_1_benefit_icon', 'fa-award'),
(199, 6, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(200, 6, 'benefits_1_benefit_text', 'Best Guarantiees'),
(201, 6, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(202, 6, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(203, 6, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(204, 6, 'benefits_2_benefit_text', 'Best Customer Service'),
(205, 6, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(206, 6, 'benefits_3_benefit_icon', 'fa-gear'),
(207, 6, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(208, 6, 'benefits_3_benefit_text', 'Best Trained technicians'),
(209, 6, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(210, 6, 'benefits', '4') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(211, 6, '_benefits', 'field_62fd9e66a1fb0'),
(212, 49, 'background_image', '17'),
(213, 49, '_background_image', 'field_62fd648144774'),
(214, 49, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(215, 49, '_banner_title', 'field_62fd64db44775'),
(216, 49, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(217, 49, '_benner_text', 'field_62fd64f944776'),
(218, 49, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(219, 49, '_banner_text', 'field_62fd64f944776'),
(220, 49, 'learn_button_button_text', 'LEARN MORE'),
(221, 49, '_learn_button_button_text', 'field_62fd9855e32b2'),
(222, 49, 'learn_button_button_link', 'https://isning.com/'),
(223, 49, '_learn_button_button_link', 'field_62fd9871e32b3'),
(224, 49, 'learn_button', ''),
(225, 49, '_learn_button', 'field_62fd982ce32b1'),
(226, 49, 'call_button_button_text', '(888) 480-9996'),
(227, 49, '_call_button_button_text', 'field_62fd9b16f58b1'),
(228, 49, 'call_button_phone_number', '8884809996'),
(229, 49, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(230, 49, 'call_button', ''),
(231, 49, '_call_button', 'field_62fd9aecf58b0'),
(232, 49, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(233, 49, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(234, 49, 'benefits_0_benefit_text', 'Best Prices'),
(235, 49, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(236, 49, 'benefits_1_benefit_icon', 'fa-award'),
(237, 49, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(238, 49, 'benefits_1_benefit_text', 'Best Guarantiees'),
(239, 49, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(240, 49, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(241, 49, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(242, 49, 'benefits_2_benefit_text', 'Best Customer Service'),
(243, 49, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(244, 49, 'benefits_3_benefit_icon', 'fa-gear'),
(245, 49, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(246, 49, 'benefits_3_benefit_text', 'Best Trained technicians'),
(247, 49, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(248, 49, 'benefits', '4'),
(249, 49, '_benefits', 'field_62fd9e66a1fb0'),
(250, 6, 'services_section_title', 'Our Services'),
(251, 6, '_services_section_title', 'field_62fda97098207'),
(252, 6, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(253, 6, '_services_section_text', 'field_62fda9b498208'),
(254, 6, 'services', '6'),
(255, 6, '_services', 'field_62fda9ea98209'),
(256, 56, 'background_image', '17'),
(257, 56, '_background_image', 'field_62fd648144774'),
(258, 56, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(259, 56, '_banner_title', 'field_62fd64db44775'),
(260, 56, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(261, 56, '_benner_text', 'field_62fd64f944776'),
(262, 56, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(263, 56, '_banner_text', 'field_62fd64f944776'),
(264, 56, 'learn_button_button_text', 'LEARN MORE'),
(265, 56, '_learn_button_button_text', 'field_62fd9855e32b2'),
(266, 56, 'learn_button_button_link', 'https://isning.com/'),
(267, 56, '_learn_button_button_link', 'field_62fd9871e32b3'),
(268, 56, 'learn_button', ''),
(269, 56, '_learn_button', 'field_62fd982ce32b1'),
(270, 56, 'call_button_button_text', '(888) 480-9996'),
(271, 56, '_call_button_button_text', 'field_62fd9b16f58b1'),
(272, 56, 'call_button_phone_number', '8884809996'),
(273, 56, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(274, 56, 'call_button', ''),
(275, 56, '_call_button', 'field_62fd9aecf58b0'),
(276, 56, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(277, 56, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(278, 56, 'benefits_0_benefit_text', 'Best Prices'),
(279, 56, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(280, 56, 'benefits_1_benefit_icon', 'fa-award'),
(281, 56, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(282, 56, 'benefits_1_benefit_text', 'Best Guarantiees'),
(283, 56, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(284, 56, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(285, 56, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(286, 56, 'benefits_2_benefit_text', 'Best Customer Service'),
(287, 56, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(288, 56, 'benefits_3_benefit_icon', 'fa-gear'),
(289, 56, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(290, 56, 'benefits_3_benefit_text', 'Best Trained technicians'),
(291, 56, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(292, 56, 'benefits', '4'),
(293, 56, '_benefits', 'field_62fd9e66a1fb0'),
(294, 56, 'services_section_title', 'Our Services'),
(295, 56, '_services_section_title', 'field_62fda97098207'),
(296, 56, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(297, 56, '_services_section_text', 'field_62fda9b498208'),
(298, 56, 'services', ''),
(299, 56, '_services', 'field_62fda9ea98209'),
(300, 6, 'services_0_service_image', '13'),
(301, 6, '_services_0_service_image', 'field_62fdaa219820a'),
(302, 6, 'services_0_service_name', 'MRI/MRA'),
(303, 6, '_services_0_service_name', 'field_62fdaa739820b'),
(304, 6, 'services_1_service_image', '13'),
(305, 6, '_services_1_service_image', 'field_62fdaa219820a'),
(306, 6, 'services_1_service_name', 'OPEN MRI'),
(307, 6, '_services_1_service_name', 'field_62fdaa739820b'),
(308, 6, 'services_2_service_image', '13'),
(309, 6, '_services_2_service_image', 'field_62fdaa219820a'),
(310, 6, 'services_2_service_name', 'MUSKULOSKELETAL') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(311, 6, '_services_2_service_name', 'field_62fdaa739820b'),
(312, 6, 'services_3_service_image', '13'),
(313, 6, '_services_3_service_image', 'field_62fdaa219820a'),
(314, 6, 'services_3_service_name', 'NEURO'),
(315, 6, '_services_3_service_name', 'field_62fdaa739820b'),
(316, 6, 'services_4_service_image', '13'),
(317, 6, '_services_4_service_image', 'field_62fdaa219820a'),
(318, 6, 'services_4_service_name', 'SPINE'),
(319, 6, '_services_4_service_name', 'field_62fdaa739820b'),
(320, 6, 'services_5_service_image', '13'),
(321, 6, '_services_5_service_image', 'field_62fdaa219820a'),
(322, 6, 'services_5_service_name', 'BODY'),
(323, 6, '_services_5_service_name', 'field_62fdaa739820b'),
(324, 57, 'background_image', '17'),
(325, 57, '_background_image', 'field_62fd648144774'),
(326, 57, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(327, 57, '_banner_title', 'field_62fd64db44775'),
(328, 57, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(329, 57, '_benner_text', 'field_62fd64f944776'),
(330, 57, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(331, 57, '_banner_text', 'field_62fd64f944776'),
(332, 57, 'learn_button_button_text', 'LEARN MORE'),
(333, 57, '_learn_button_button_text', 'field_62fd9855e32b2'),
(334, 57, 'learn_button_button_link', 'https://isning.com/'),
(335, 57, '_learn_button_button_link', 'field_62fd9871e32b3'),
(336, 57, 'learn_button', ''),
(337, 57, '_learn_button', 'field_62fd982ce32b1'),
(338, 57, 'call_button_button_text', '(888) 480-9996'),
(339, 57, '_call_button_button_text', 'field_62fd9b16f58b1'),
(340, 57, 'call_button_phone_number', '8884809996'),
(341, 57, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(342, 57, 'call_button', ''),
(343, 57, '_call_button', 'field_62fd9aecf58b0'),
(344, 57, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(345, 57, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(346, 57, 'benefits_0_benefit_text', 'Best Prices'),
(347, 57, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(348, 57, 'benefits_1_benefit_icon', 'fa-award'),
(349, 57, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(350, 57, 'benefits_1_benefit_text', 'Best Guarantiees'),
(351, 57, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(352, 57, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(353, 57, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(354, 57, 'benefits_2_benefit_text', 'Best Customer Service'),
(355, 57, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(356, 57, 'benefits_3_benefit_icon', 'fa-gear'),
(357, 57, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(358, 57, 'benefits_3_benefit_text', 'Best Trained technicians'),
(359, 57, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(360, 57, 'benefits', '4'),
(361, 57, '_benefits', 'field_62fd9e66a1fb0'),
(362, 57, 'services_section_title', 'Our Services'),
(363, 57, '_services_section_title', 'field_62fda97098207'),
(364, 57, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(365, 57, '_services_section_text', 'field_62fda9b498208'),
(366, 57, 'services', '6'),
(367, 57, '_services', 'field_62fda9ea98209'),
(368, 57, 'services_0_service_image', '13'),
(369, 57, '_services_0_service_image', 'field_62fdaa219820a'),
(370, 57, 'services_0_service_name', 'MRI/MRA'),
(371, 57, '_services_0_service_name', 'field_62fdaa739820b'),
(372, 57, 'services_1_service_image', '13'),
(373, 57, '_services_1_service_image', 'field_62fdaa219820a'),
(374, 57, 'services_1_service_name', 'OPEN MRI'),
(375, 57, '_services_1_service_name', 'field_62fdaa739820b'),
(376, 57, 'services_2_service_image', '13'),
(377, 57, '_services_2_service_image', 'field_62fdaa219820a'),
(378, 57, 'services_2_service_name', 'MUSKULOSKELETAL'),
(379, 57, '_services_2_service_name', 'field_62fdaa739820b'),
(380, 57, 'services_3_service_image', '13'),
(381, 57, '_services_3_service_image', 'field_62fdaa219820a'),
(382, 57, 'services_3_service_name', 'NEURO'),
(383, 57, '_services_3_service_name', 'field_62fdaa739820b'),
(384, 57, 'services_4_service_image', '13'),
(385, 57, '_services_4_service_image', 'field_62fdaa219820a'),
(386, 57, 'services_4_service_name', 'SPINE'),
(387, 57, '_services_4_service_name', 'field_62fdaa739820b'),
(388, 57, 'services_5_service_image', '13'),
(389, 57, '_services_5_service_image', 'field_62fdaa219820a'),
(390, 57, 'services_5_service_name', 'BODY'),
(391, 57, '_services_5_service_name', 'field_62fdaa739820b'),
(392, 58, 'background_image', '17'),
(393, 58, '_background_image', 'field_62fd648144774'),
(394, 58, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(395, 58, '_banner_title', 'field_62fd64db44775'),
(396, 58, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(397, 58, '_benner_text', 'field_62fd64f944776'),
(398, 58, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(399, 58, '_banner_text', 'field_62fd64f944776'),
(400, 58, 'learn_button_button_text', 'LEARN MORE'),
(401, 58, '_learn_button_button_text', 'field_62fd9855e32b2'),
(402, 58, 'learn_button_button_link', 'https://isning.com/'),
(403, 58, '_learn_button_button_link', 'field_62fd9871e32b3'),
(404, 58, 'learn_button', ''),
(405, 58, '_learn_button', 'field_62fd982ce32b1'),
(406, 58, 'call_button_button_text', '(888) 480-9996'),
(407, 58, '_call_button_button_text', 'field_62fd9b16f58b1'),
(408, 58, 'call_button_phone_number', '8884809996'),
(409, 58, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(410, 58, 'call_button', '') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(411, 58, '_call_button', 'field_62fd9aecf58b0'),
(412, 58, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(413, 58, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(414, 58, 'benefits_0_benefit_text', 'Best Prices'),
(415, 58, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(416, 58, 'benefits_1_benefit_icon', 'fa-award'),
(417, 58, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(418, 58, 'benefits_1_benefit_text', 'Best Guarantiees'),
(419, 58, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(420, 58, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(421, 58, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(422, 58, 'benefits_2_benefit_text', 'Best Customer Service'),
(423, 58, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(424, 58, 'benefits_3_benefit_icon', 'fa-gear'),
(425, 58, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(426, 58, 'benefits_3_benefit_text', 'Best Trained technicians'),
(427, 58, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(428, 58, 'benefits', '4'),
(429, 58, '_benefits', 'field_62fd9e66a1fb0'),
(430, 58, 'services_section_title', 'Our Services'),
(431, 58, '_services_section_title', 'field_62fda97098207'),
(432, 58, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(433, 58, '_services_section_text', 'field_62fda9b498208'),
(434, 58, 'services', '6'),
(435, 58, '_services', 'field_62fda9ea98209'),
(436, 58, 'services_0_service_image', '13'),
(437, 58, '_services_0_service_image', 'field_62fdaa219820a'),
(438, 58, 'services_0_service_name', 'MRI/MRA'),
(439, 58, '_services_0_service_name', 'field_62fdaa739820b'),
(440, 58, 'services_1_service_image', '13'),
(441, 58, '_services_1_service_image', 'field_62fdaa219820a'),
(442, 58, 'services_1_service_name', 'OPEN MRI'),
(443, 58, '_services_1_service_name', 'field_62fdaa739820b'),
(444, 58, 'services_2_service_image', '13'),
(445, 58, '_services_2_service_image', 'field_62fdaa219820a'),
(446, 58, 'services_2_service_name', 'MUSKULOSKELETAL'),
(447, 58, '_services_2_service_name', 'field_62fdaa739820b'),
(448, 58, 'services_3_service_image', '13'),
(449, 58, '_services_3_service_image', 'field_62fdaa219820a'),
(450, 58, 'services_3_service_name', 'NEURO'),
(451, 58, '_services_3_service_name', 'field_62fdaa739820b'),
(452, 58, 'services_4_service_image', '13'),
(453, 58, '_services_4_service_image', 'field_62fdaa219820a'),
(454, 58, 'services_4_service_name', 'SPINE'),
(455, 58, '_services_4_service_name', 'field_62fdaa739820b'),
(456, 58, 'services_5_service_image', '13'),
(457, 58, '_services_5_service_image', 'field_62fdaa219820a'),
(458, 58, 'services_5_service_name', 'BODY'),
(459, 58, '_services_5_service_name', 'field_62fdaa739820b'),
(460, 6, 'contact_section_text', 'Schedule online now!'),
(461, 6, '_contact_section_text', 'field_62fdaee4f175a'),
(462, 6, 'contact_phone_phone_text', '(888) 780-9996'),
(463, 6, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(464, 6, 'contact_phone_phone_number', '8887809996'),
(465, 6, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(466, 6, 'contact_phone', ''),
(467, 6, '_contact_phone', 'field_62fdaefbf175b'),
(468, 6, 'email_button_button_text', 'Email Us Today !'),
(469, 6, '_email_button_button_text', 'field_62fdafe0f175f'),
(470, 6, 'email_button_button_link', 'https://isning.com/'),
(471, 6, '_email_button_button_link', 'field_62fdafeef1760'),
(472, 6, 'email_button', ''),
(473, 6, '_email_button', 'field_62fdaf4cf175e'),
(474, 68, 'background_image', '17'),
(475, 68, '_background_image', 'field_62fd648144774'),
(476, 68, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(477, 68, '_banner_title', 'field_62fd64db44775'),
(478, 68, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(479, 68, '_benner_text', 'field_62fd64f944776'),
(480, 68, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(481, 68, '_banner_text', 'field_62fd64f944776'),
(482, 68, 'learn_button_button_text', 'LEARN MORE'),
(483, 68, '_learn_button_button_text', 'field_62fd9855e32b2'),
(484, 68, 'learn_button_button_link', 'https://isning.com/'),
(485, 68, '_learn_button_button_link', 'field_62fd9871e32b3'),
(486, 68, 'learn_button', ''),
(487, 68, '_learn_button', 'field_62fd982ce32b1'),
(488, 68, 'call_button_button_text', '(888) 480-9996'),
(489, 68, '_call_button_button_text', 'field_62fd9b16f58b1'),
(490, 68, 'call_button_phone_number', '8884809996'),
(491, 68, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(492, 68, 'call_button', ''),
(493, 68, '_call_button', 'field_62fd9aecf58b0'),
(494, 68, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(495, 68, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(496, 68, 'benefits_0_benefit_text', 'Best Prices'),
(497, 68, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(498, 68, 'benefits_1_benefit_icon', 'fa-award'),
(499, 68, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(500, 68, 'benefits_1_benefit_text', 'Best Guarantiees'),
(501, 68, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(502, 68, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(503, 68, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(504, 68, 'benefits_2_benefit_text', 'Best Customer Service'),
(505, 68, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(506, 68, 'benefits_3_benefit_icon', 'fa-gear'),
(507, 68, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(508, 68, 'benefits_3_benefit_text', 'Best Trained technicians'),
(509, 68, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(510, 68, 'benefits', '4') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(511, 68, '_benefits', 'field_62fd9e66a1fb0'),
(512, 68, 'services_section_title', 'Our Services'),
(513, 68, '_services_section_title', 'field_62fda97098207'),
(514, 68, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(515, 68, '_services_section_text', 'field_62fda9b498208'),
(516, 68, 'services', '6'),
(517, 68, '_services', 'field_62fda9ea98209'),
(518, 68, 'services_0_service_image', '13'),
(519, 68, '_services_0_service_image', 'field_62fdaa219820a'),
(520, 68, 'services_0_service_name', 'MRI/MRA'),
(521, 68, '_services_0_service_name', 'field_62fdaa739820b'),
(522, 68, 'services_1_service_image', '13'),
(523, 68, '_services_1_service_image', 'field_62fdaa219820a'),
(524, 68, 'services_1_service_name', 'OPEN MRI'),
(525, 68, '_services_1_service_name', 'field_62fdaa739820b'),
(526, 68, 'services_2_service_image', '13'),
(527, 68, '_services_2_service_image', 'field_62fdaa219820a'),
(528, 68, 'services_2_service_name', 'MUSKULOSKELETAL'),
(529, 68, '_services_2_service_name', 'field_62fdaa739820b'),
(530, 68, 'services_3_service_image', '13'),
(531, 68, '_services_3_service_image', 'field_62fdaa219820a'),
(532, 68, 'services_3_service_name', 'NEURO'),
(533, 68, '_services_3_service_name', 'field_62fdaa739820b'),
(534, 68, 'services_4_service_image', '13'),
(535, 68, '_services_4_service_image', 'field_62fdaa219820a'),
(536, 68, 'services_4_service_name', 'SPINE'),
(537, 68, '_services_4_service_name', 'field_62fdaa739820b'),
(538, 68, 'services_5_service_image', '13'),
(539, 68, '_services_5_service_image', 'field_62fdaa219820a'),
(540, 68, 'services_5_service_name', 'BODY'),
(541, 68, '_services_5_service_name', 'field_62fdaa739820b'),
(542, 68, 'contact_section_text', 'Schedule online now!'),
(543, 68, '_contact_section_text', 'field_62fdaee4f175a'),
(544, 68, 'contact_phone_phone_text', '(888) 780-9996'),
(545, 68, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(546, 68, 'contact_phone_phone_number', '8887809996'),
(547, 68, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(548, 68, 'contact_phone', ''),
(549, 68, '_contact_phone', 'field_62fdaefbf175b'),
(550, 68, 'email_button_button_text', 'Email Us Today !'),
(551, 68, '_email_button_button_text', 'field_62fdafe0f175f'),
(552, 68, 'email_button_button_link', 'https://isning.com/'),
(553, 68, '_email_button_button_link', 'field_62fdafeef1760'),
(554, 68, 'email_button', ''),
(555, 68, '_email_button', 'field_62fdaf4cf175e'),
(556, 6, 'testimonials_section_title', 'Testimonials'),
(557, 6, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(558, 6, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(559, 6, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(560, 72, 'background_image', '17'),
(561, 72, '_background_image', 'field_62fd648144774'),
(562, 72, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(563, 72, '_banner_title', 'field_62fd64db44775'),
(564, 72, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(565, 72, '_benner_text', 'field_62fd64f944776'),
(566, 72, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(567, 72, '_banner_text', 'field_62fd64f944776'),
(568, 72, 'learn_button_button_text', 'LEARN MORE'),
(569, 72, '_learn_button_button_text', 'field_62fd9855e32b2'),
(570, 72, 'learn_button_button_link', 'https://isning.com/'),
(571, 72, '_learn_button_button_link', 'field_62fd9871e32b3'),
(572, 72, 'learn_button', ''),
(573, 72, '_learn_button', 'field_62fd982ce32b1'),
(574, 72, 'call_button_button_text', '(888) 480-9996'),
(575, 72, '_call_button_button_text', 'field_62fd9b16f58b1'),
(576, 72, 'call_button_phone_number', '8884809996'),
(577, 72, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(578, 72, 'call_button', ''),
(579, 72, '_call_button', 'field_62fd9aecf58b0'),
(580, 72, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(581, 72, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(582, 72, 'benefits_0_benefit_text', 'Best Prices'),
(583, 72, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(584, 72, 'benefits_1_benefit_icon', 'fa-award'),
(585, 72, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(586, 72, 'benefits_1_benefit_text', 'Best Guarantiees'),
(587, 72, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(588, 72, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(589, 72, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(590, 72, 'benefits_2_benefit_text', 'Best Customer Service'),
(591, 72, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(592, 72, 'benefits_3_benefit_icon', 'fa-gear'),
(593, 72, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(594, 72, 'benefits_3_benefit_text', 'Best Trained technicians'),
(595, 72, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(596, 72, 'benefits', '4'),
(597, 72, '_benefits', 'field_62fd9e66a1fb0'),
(598, 72, 'services_section_title', 'Our Services'),
(599, 72, '_services_section_title', 'field_62fda97098207'),
(600, 72, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(601, 72, '_services_section_text', 'field_62fda9b498208'),
(602, 72, 'services', '6'),
(603, 72, '_services', 'field_62fda9ea98209'),
(604, 72, 'services_0_service_image', '13'),
(605, 72, '_services_0_service_image', 'field_62fdaa219820a'),
(606, 72, 'services_0_service_name', 'MRI/MRA'),
(607, 72, '_services_0_service_name', 'field_62fdaa739820b'),
(608, 72, 'services_1_service_image', '13'),
(609, 72, '_services_1_service_image', 'field_62fdaa219820a'),
(610, 72, 'services_1_service_name', 'OPEN MRI') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(611, 72, '_services_1_service_name', 'field_62fdaa739820b'),
(612, 72, 'services_2_service_image', '13'),
(613, 72, '_services_2_service_image', 'field_62fdaa219820a'),
(614, 72, 'services_2_service_name', 'MUSKULOSKELETAL'),
(615, 72, '_services_2_service_name', 'field_62fdaa739820b'),
(616, 72, 'services_3_service_image', '13'),
(617, 72, '_services_3_service_image', 'field_62fdaa219820a'),
(618, 72, 'services_3_service_name', 'NEURO'),
(619, 72, '_services_3_service_name', 'field_62fdaa739820b'),
(620, 72, 'services_4_service_image', '13'),
(621, 72, '_services_4_service_image', 'field_62fdaa219820a'),
(622, 72, 'services_4_service_name', 'SPINE'),
(623, 72, '_services_4_service_name', 'field_62fdaa739820b'),
(624, 72, 'services_5_service_image', '13'),
(625, 72, '_services_5_service_image', 'field_62fdaa219820a'),
(626, 72, 'services_5_service_name', 'BODY'),
(627, 72, '_services_5_service_name', 'field_62fdaa739820b'),
(628, 72, 'contact_section_text', 'Schedule online now!'),
(629, 72, '_contact_section_text', 'field_62fdaee4f175a'),
(630, 72, 'contact_phone_phone_text', '(888) 780-9996'),
(631, 72, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(632, 72, 'contact_phone_phone_number', '8887809996'),
(633, 72, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(634, 72, 'contact_phone', ''),
(635, 72, '_contact_phone', 'field_62fdaefbf175b'),
(636, 72, 'email_button_button_text', 'Email Us Today !'),
(637, 72, '_email_button_button_text', 'field_62fdafe0f175f'),
(638, 72, 'email_button_button_link', 'https://isning.com/'),
(639, 72, '_email_button_button_link', 'field_62fdafeef1760'),
(640, 72, 'email_button', ''),
(641, 72, '_email_button', 'field_62fdaf4cf175e'),
(642, 72, 'testimonials_section_title', 'Testimonials'),
(643, 72, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(644, 72, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(645, 72, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(646, 73, 'background_image', '17'),
(647, 73, '_background_image', 'field_62fd648144774'),
(648, 73, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(649, 73, '_banner_title', 'field_62fd64db44775'),
(650, 73, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(651, 73, '_benner_text', 'field_62fd64f944776'),
(652, 73, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(653, 73, '_banner_text', 'field_62fd64f944776'),
(654, 73, 'learn_button_button_text', 'LEARN MORE'),
(655, 73, '_learn_button_button_text', 'field_62fd9855e32b2'),
(656, 73, 'learn_button_button_link', 'https://isning.com/'),
(657, 73, '_learn_button_button_link', 'field_62fd9871e32b3'),
(658, 73, 'learn_button', ''),
(659, 73, '_learn_button', 'field_62fd982ce32b1'),
(660, 73, 'call_button_button_text', '(888) 480-9996'),
(661, 73, '_call_button_button_text', 'field_62fd9b16f58b1'),
(662, 73, 'call_button_phone_number', '8884809996'),
(663, 73, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(664, 73, 'call_button', ''),
(665, 73, '_call_button', 'field_62fd9aecf58b0'),
(666, 73, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(667, 73, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(668, 73, 'benefits_0_benefit_text', 'Best Prices'),
(669, 73, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(670, 73, 'benefits_1_benefit_icon', 'fa-award'),
(671, 73, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(672, 73, 'benefits_1_benefit_text', 'Best Guarantiees'),
(673, 73, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(674, 73, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(675, 73, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(676, 73, 'benefits_2_benefit_text', 'Best Customer Service'),
(677, 73, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(678, 73, 'benefits_3_benefit_icon', 'fa-gear'),
(679, 73, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(680, 73, 'benefits_3_benefit_text', 'Best Trained technicians'),
(681, 73, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(682, 73, 'benefits', '4'),
(683, 73, '_benefits', 'field_62fd9e66a1fb0'),
(684, 73, 'services_section_title', 'Our Services'),
(685, 73, '_services_section_title', 'field_62fda97098207'),
(686, 73, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(687, 73, '_services_section_text', 'field_62fda9b498208'),
(688, 73, 'services', '6'),
(689, 73, '_services', 'field_62fda9ea98209'),
(690, 73, 'services_0_service_image', '13'),
(691, 73, '_services_0_service_image', 'field_62fdaa219820a'),
(692, 73, 'services_0_service_name', 'MRI/MRA'),
(693, 73, '_services_0_service_name', 'field_62fdaa739820b'),
(694, 73, 'services_1_service_image', '13'),
(695, 73, '_services_1_service_image', 'field_62fdaa219820a'),
(696, 73, 'services_1_service_name', 'OPEN MRI'),
(697, 73, '_services_1_service_name', 'field_62fdaa739820b'),
(698, 73, 'services_2_service_image', '13'),
(699, 73, '_services_2_service_image', 'field_62fdaa219820a'),
(700, 73, 'services_2_service_name', 'MUSKULOSKELETAL'),
(701, 73, '_services_2_service_name', 'field_62fdaa739820b'),
(702, 73, 'services_3_service_image', '13'),
(703, 73, '_services_3_service_image', 'field_62fdaa219820a'),
(704, 73, 'services_3_service_name', 'NEURO'),
(705, 73, '_services_3_service_name', 'field_62fdaa739820b'),
(706, 73, 'services_4_service_image', '13'),
(707, 73, '_services_4_service_image', 'field_62fdaa219820a'),
(708, 73, 'services_4_service_name', 'SPINE'),
(709, 73, '_services_4_service_name', 'field_62fdaa739820b'),
(710, 73, 'services_5_service_image', '13') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(711, 73, '_services_5_service_image', 'field_62fdaa219820a'),
(712, 73, 'services_5_service_name', 'BODY'),
(713, 73, '_services_5_service_name', 'field_62fdaa739820b'),
(714, 73, 'contact_section_text', 'Schedule online now!'),
(715, 73, '_contact_section_text', 'field_62fdaee4f175a'),
(716, 73, 'contact_phone_phone_text', '(888) 780-9996'),
(717, 73, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(718, 73, 'contact_phone_phone_number', '8887809996'),
(719, 73, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(720, 73, 'contact_phone', ''),
(721, 73, '_contact_phone', 'field_62fdaefbf175b'),
(722, 73, 'email_button_button_text', 'Email Us Today !'),
(723, 73, '_email_button_button_text', 'field_62fdafe0f175f'),
(724, 73, 'email_button_button_link', 'https://isning.com/'),
(725, 73, '_email_button_button_link', 'field_62fdafeef1760'),
(726, 73, 'email_button', ''),
(727, 73, '_email_button', 'field_62fdaf4cf175e'),
(728, 73, 'testimonials_section_title', 'Testimonials'),
(729, 73, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(730, 73, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(731, 73, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(732, 6, 'testimonials_0_testimonial_video', 'Z3xkHmC-KQE'),
(733, 6, '_testimonials_0_testimonial_video', 'field_62fdba076cddc'),
(734, 6, 'testimonials_0_testimonial_picture', '14'),
(735, 6, '_testimonials_0_testimonial_picture', 'field_62fdb9bfc6f9d'),
(736, 6, 'testimonials_0_testimonial_name', 'Tina Martin'),
(737, 6, '_testimonials_0_testimonial_name', 'field_62fdb9d1c6f9e'),
(738, 6, 'testimonials_0_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!'),
(739, 6, '_testimonials_0_testimonial_text', 'field_62fdb9e0c6f9f'),
(740, 6, 'testimonials_1_testimonial_video', 'nam90gorcPs'),
(741, 6, '_testimonials_1_testimonial_video', 'field_62fdba076cddc'),
(742, 6, 'testimonials_1_testimonial_picture', '14'),
(743, 6, '_testimonials_1_testimonial_picture', 'field_62fdb9bfc6f9d'),
(744, 6, 'testimonials_1_testimonial_name', 'Tyna Martin'),
(745, 6, '_testimonials_1_testimonial_name', 'field_62fdb9d1c6f9e'),
(746, 6, 'testimonials_1_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(747, 6, '_testimonials_1_testimonial_text', 'field_62fdb9e0c6f9f'),
(748, 6, 'testimonials_2_testimonial_video', 'x2D7jHfitzk'),
(749, 6, '_testimonials_2_testimonial_video', 'field_62fdba076cddc'),
(750, 6, 'testimonials_2_testimonial_picture', '14'),
(751, 6, '_testimonials_2_testimonial_picture', 'field_62fdb9bfc6f9d'),
(752, 6, 'testimonials_2_testimonial_name', 'Martins Tina'),
(753, 6, '_testimonials_2_testimonial_name', 'field_62fdb9d1c6f9e'),
(754, 6, 'testimonials_2_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(755, 6, '_testimonials_2_testimonial_text', 'field_62fdb9e0c6f9f'),
(756, 6, 'testimonials', '3'),
(757, 6, '_testimonials', 'field_62fdb99ac6f9c'),
(758, 79, 'background_image', '17'),
(759, 79, '_background_image', 'field_62fd648144774'),
(760, 79, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(761, 79, '_banner_title', 'field_62fd64db44775'),
(762, 79, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(763, 79, '_benner_text', 'field_62fd64f944776'),
(764, 79, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(765, 79, '_banner_text', 'field_62fd64f944776'),
(766, 79, 'learn_button_button_text', 'LEARN MORE'),
(767, 79, '_learn_button_button_text', 'field_62fd9855e32b2'),
(768, 79, 'learn_button_button_link', 'https://isning.com/'),
(769, 79, '_learn_button_button_link', 'field_62fd9871e32b3'),
(770, 79, 'learn_button', ''),
(771, 79, '_learn_button', 'field_62fd982ce32b1'),
(772, 79, 'call_button_button_text', '(888) 480-9996'),
(773, 79, '_call_button_button_text', 'field_62fd9b16f58b1'),
(774, 79, 'call_button_phone_number', '8884809996'),
(775, 79, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(776, 79, 'call_button', ''),
(777, 79, '_call_button', 'field_62fd9aecf58b0'),
(778, 79, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(779, 79, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(780, 79, 'benefits_0_benefit_text', 'Best Prices'),
(781, 79, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(782, 79, 'benefits_1_benefit_icon', 'fa-award'),
(783, 79, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(784, 79, 'benefits_1_benefit_text', 'Best Guarantiees'),
(785, 79, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(786, 79, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(787, 79, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(788, 79, 'benefits_2_benefit_text', 'Best Customer Service'),
(789, 79, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(790, 79, 'benefits_3_benefit_icon', 'fa-gear'),
(791, 79, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(792, 79, 'benefits_3_benefit_text', 'Best Trained technicians'),
(793, 79, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(794, 79, 'benefits', '4'),
(795, 79, '_benefits', 'field_62fd9e66a1fb0'),
(796, 79, 'services_section_title', 'Our Services'),
(797, 79, '_services_section_title', 'field_62fda97098207'),
(798, 79, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(799, 79, '_services_section_text', 'field_62fda9b498208'),
(800, 79, 'services', '6'),
(801, 79, '_services', 'field_62fda9ea98209'),
(802, 79, 'services_0_service_image', '13'),
(803, 79, '_services_0_service_image', 'field_62fdaa219820a'),
(804, 79, 'services_0_service_name', 'MRI/MRA'),
(805, 79, '_services_0_service_name', 'field_62fdaa739820b'),
(806, 79, 'services_1_service_image', '13'),
(807, 79, '_services_1_service_image', 'field_62fdaa219820a'),
(808, 79, 'services_1_service_name', 'OPEN MRI'),
(809, 79, '_services_1_service_name', 'field_62fdaa739820b'),
(810, 79, 'services_2_service_image', '13') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(811, 79, '_services_2_service_image', 'field_62fdaa219820a'),
(812, 79, 'services_2_service_name', 'MUSKULOSKELETAL'),
(813, 79, '_services_2_service_name', 'field_62fdaa739820b'),
(814, 79, 'services_3_service_image', '13'),
(815, 79, '_services_3_service_image', 'field_62fdaa219820a'),
(816, 79, 'services_3_service_name', 'NEURO'),
(817, 79, '_services_3_service_name', 'field_62fdaa739820b'),
(818, 79, 'services_4_service_image', '13'),
(819, 79, '_services_4_service_image', 'field_62fdaa219820a'),
(820, 79, 'services_4_service_name', 'SPINE'),
(821, 79, '_services_4_service_name', 'field_62fdaa739820b'),
(822, 79, 'services_5_service_image', '13'),
(823, 79, '_services_5_service_image', 'field_62fdaa219820a'),
(824, 79, 'services_5_service_name', 'BODY'),
(825, 79, '_services_5_service_name', 'field_62fdaa739820b'),
(826, 79, 'contact_section_text', 'Schedule online now!'),
(827, 79, '_contact_section_text', 'field_62fdaee4f175a'),
(828, 79, 'contact_phone_phone_text', '(888) 780-9996'),
(829, 79, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(830, 79, 'contact_phone_phone_number', '8887809996'),
(831, 79, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(832, 79, 'contact_phone', ''),
(833, 79, '_contact_phone', 'field_62fdaefbf175b'),
(834, 79, 'email_button_button_text', 'Email Us Today !'),
(835, 79, '_email_button_button_text', 'field_62fdafe0f175f'),
(836, 79, 'email_button_button_link', 'https://isning.com/'),
(837, 79, '_email_button_button_link', 'field_62fdafeef1760'),
(838, 79, 'email_button', ''),
(839, 79, '_email_button', 'field_62fdaf4cf175e'),
(840, 79, 'testimonials_section_title', 'Testimonials'),
(841, 79, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(842, 79, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(843, 79, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(844, 79, 'testimonials_0_testimonial_video', ''),
(845, 79, '_testimonials_0_testimonial_video', 'field_62fdba076cddc'),
(846, 79, 'testimonials_0_testimonial_picture', '14'),
(847, 79, '_testimonials_0_testimonial_picture', 'field_62fdb9bfc6f9d'),
(848, 79, 'testimonials_0_testimonial_name', 'Tina Martin'),
(849, 79, '_testimonials_0_testimonial_name', 'field_62fdb9d1c6f9e'),
(850, 79, 'testimonials_0_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!'),
(851, 79, '_testimonials_0_testimonial_text', 'field_62fdb9e0c6f9f'),
(852, 79, 'testimonials_1_testimonial_video', ''),
(853, 79, '_testimonials_1_testimonial_video', 'field_62fdba076cddc'),
(854, 79, 'testimonials_1_testimonial_picture', '14'),
(855, 79, '_testimonials_1_testimonial_picture', 'field_62fdb9bfc6f9d'),
(856, 79, 'testimonials_1_testimonial_name', 'Tyna Martin'),
(857, 79, '_testimonials_1_testimonial_name', 'field_62fdb9d1c6f9e'),
(858, 79, 'testimonials_1_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(859, 79, '_testimonials_1_testimonial_text', 'field_62fdb9e0c6f9f'),
(860, 79, 'testimonials_2_testimonial_video', ''),
(861, 79, '_testimonials_2_testimonial_video', 'field_62fdba076cddc'),
(862, 79, 'testimonials_2_testimonial_picture', '14'),
(863, 79, '_testimonials_2_testimonial_picture', 'field_62fdb9bfc6f9d'),
(864, 79, 'testimonials_2_testimonial_name', 'Martins Tina'),
(865, 79, '_testimonials_2_testimonial_name', 'field_62fdb9d1c6f9e'),
(866, 79, 'testimonials_2_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(867, 79, '_testimonials_2_testimonial_text', 'field_62fdb9e0c6f9f'),
(868, 79, 'testimonials', '3'),
(869, 79, '_testimonials', 'field_62fdb99ac6f9c'),
(870, 80, 'background_image', '17'),
(871, 80, '_background_image', 'field_62fd648144774'),
(872, 80, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(873, 80, '_banner_title', 'field_62fd64db44775'),
(874, 80, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(875, 80, '_benner_text', 'field_62fd64f944776'),
(876, 80, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(877, 80, '_banner_text', 'field_62fd64f944776'),
(878, 80, 'learn_button_button_text', 'LEARN MORE'),
(879, 80, '_learn_button_button_text', 'field_62fd9855e32b2'),
(880, 80, 'learn_button_button_link', 'https://isning.com/'),
(881, 80, '_learn_button_button_link', 'field_62fd9871e32b3'),
(882, 80, 'learn_button', ''),
(883, 80, '_learn_button', 'field_62fd982ce32b1'),
(884, 80, 'call_button_button_text', '(888) 480-9996'),
(885, 80, '_call_button_button_text', 'field_62fd9b16f58b1'),
(886, 80, 'call_button_phone_number', '8884809996'),
(887, 80, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(888, 80, 'call_button', ''),
(889, 80, '_call_button', 'field_62fd9aecf58b0'),
(890, 80, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(891, 80, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(892, 80, 'benefits_0_benefit_text', 'Best Prices'),
(893, 80, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(894, 80, 'benefits_1_benefit_icon', 'fa-award'),
(895, 80, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(896, 80, 'benefits_1_benefit_text', 'Best Guarantiees'),
(897, 80, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(898, 80, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(899, 80, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(900, 80, 'benefits_2_benefit_text', 'Best Customer Service'),
(901, 80, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(902, 80, 'benefits_3_benefit_icon', 'fa-gear'),
(903, 80, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(904, 80, 'benefits_3_benefit_text', 'Best Trained technicians'),
(905, 80, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(906, 80, 'benefits', '4'),
(907, 80, '_benefits', 'field_62fd9e66a1fb0'),
(908, 80, 'services_section_title', 'Our Services'),
(909, 80, '_services_section_title', 'field_62fda97098207'),
(910, 80, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(911, 80, '_services_section_text', 'field_62fda9b498208'),
(912, 80, 'services', '6'),
(913, 80, '_services', 'field_62fda9ea98209'),
(914, 80, 'services_0_service_image', '13'),
(915, 80, '_services_0_service_image', 'field_62fdaa219820a'),
(916, 80, 'services_0_service_name', 'MRI/MRA'),
(917, 80, '_services_0_service_name', 'field_62fdaa739820b'),
(918, 80, 'services_1_service_image', '13'),
(919, 80, '_services_1_service_image', 'field_62fdaa219820a'),
(920, 80, 'services_1_service_name', 'OPEN MRI'),
(921, 80, '_services_1_service_name', 'field_62fdaa739820b'),
(922, 80, 'services_2_service_image', '13'),
(923, 80, '_services_2_service_image', 'field_62fdaa219820a'),
(924, 80, 'services_2_service_name', 'MUSKULOSKELETAL'),
(925, 80, '_services_2_service_name', 'field_62fdaa739820b'),
(926, 80, 'services_3_service_image', '13'),
(927, 80, '_services_3_service_image', 'field_62fdaa219820a'),
(928, 80, 'services_3_service_name', 'NEURO'),
(929, 80, '_services_3_service_name', 'field_62fdaa739820b'),
(930, 80, 'services_4_service_image', '13'),
(931, 80, '_services_4_service_image', 'field_62fdaa219820a'),
(932, 80, 'services_4_service_name', 'SPINE'),
(933, 80, '_services_4_service_name', 'field_62fdaa739820b'),
(934, 80, 'services_5_service_image', '13'),
(935, 80, '_services_5_service_image', 'field_62fdaa219820a'),
(936, 80, 'services_5_service_name', 'BODY'),
(937, 80, '_services_5_service_name', 'field_62fdaa739820b'),
(938, 80, 'contact_section_text', 'Schedule online now!'),
(939, 80, '_contact_section_text', 'field_62fdaee4f175a'),
(940, 80, 'contact_phone_phone_text', '(888) 780-9996'),
(941, 80, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(942, 80, 'contact_phone_phone_number', '8887809996'),
(943, 80, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(944, 80, 'contact_phone', ''),
(945, 80, '_contact_phone', 'field_62fdaefbf175b'),
(946, 80, 'email_button_button_text', 'Email Us Today !'),
(947, 80, '_email_button_button_text', 'field_62fdafe0f175f'),
(948, 80, 'email_button_button_link', 'https://isning.com/'),
(949, 80, '_email_button_button_link', 'field_62fdafeef1760'),
(950, 80, 'email_button', ''),
(951, 80, '_email_button', 'field_62fdaf4cf175e'),
(952, 80, 'testimonials_section_title', 'Testimonials'),
(953, 80, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(954, 80, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(955, 80, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(956, 80, 'testimonials_0_testimonial_video', ''),
(957, 80, '_testimonials_0_testimonial_video', 'field_62fdba076cddc'),
(958, 80, 'testimonials_0_testimonial_picture', '14'),
(959, 80, '_testimonials_0_testimonial_picture', 'field_62fdb9bfc6f9d'),
(960, 80, 'testimonials_0_testimonial_name', 'Tina Martin'),
(961, 80, '_testimonials_0_testimonial_name', 'field_62fdb9d1c6f9e'),
(962, 80, 'testimonials_0_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!'),
(963, 80, '_testimonials_0_testimonial_text', 'field_62fdb9e0c6f9f'),
(964, 80, 'testimonials_1_testimonial_video', ''),
(965, 80, '_testimonials_1_testimonial_video', 'field_62fdba076cddc'),
(966, 80, 'testimonials_1_testimonial_picture', '14'),
(967, 80, '_testimonials_1_testimonial_picture', 'field_62fdb9bfc6f9d'),
(968, 80, 'testimonials_1_testimonial_name', 'Tyna Martin'),
(969, 80, '_testimonials_1_testimonial_name', 'field_62fdb9d1c6f9e'),
(970, 80, 'testimonials_1_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(971, 80, '_testimonials_1_testimonial_text', 'field_62fdb9e0c6f9f'),
(972, 80, 'testimonials_2_testimonial_video', ''),
(973, 80, '_testimonials_2_testimonial_video', 'field_62fdba076cddc'),
(974, 80, 'testimonials_2_testimonial_picture', '14'),
(975, 80, '_testimonials_2_testimonial_picture', 'field_62fdb9bfc6f9d'),
(976, 80, 'testimonials_2_testimonial_name', 'Martins Tina'),
(977, 80, '_testimonials_2_testimonial_name', 'field_62fdb9d1c6f9e'),
(978, 80, 'testimonials_2_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(979, 80, '_testimonials_2_testimonial_text', 'field_62fdb9e0c6f9f'),
(980, 80, 'testimonials', '3'),
(981, 80, '_testimonials', 'field_62fdb99ac6f9c'),
(982, 81, '_edit_last', '1'),
(983, 81, '_edit_lock', '1660798052:1'),
(984, 88, '_edit_last', '1'),
(985, 88, '_edit_lock', '1660798398:1'),
(986, 93, 'background_image', '17'),
(987, 93, '_background_image', 'field_62fd648144774'),
(988, 93, 'banner_title', 'The World\'s Most Advanced Body Scaning Systems'),
(989, 93, '_banner_title', 'field_62fd64db44775'),
(990, 93, 'benner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(991, 93, '_benner_text', 'field_62fd64f944776'),
(992, 93, 'banner_text', 'Welcome to health scan imaging, Southern California\'s premier imaging centers, with 11 convenient locations for early diagnosis od disease using X-ray, MRI, CT, and Ultrasound.'),
(993, 93, '_banner_text', 'field_62fd64f944776'),
(994, 93, 'learn_button_button_text', 'LEARN MORE'),
(995, 93, '_learn_button_button_text', 'field_62fd9855e32b2'),
(996, 93, 'learn_button_button_link', 'https://isning.com/'),
(997, 93, '_learn_button_button_link', 'field_62fd9871e32b3'),
(998, 93, 'learn_button', ''),
(999, 93, '_learn_button', 'field_62fd982ce32b1'),
(1000, 93, 'call_button_button_text', '(888) 480-9996'),
(1001, 93, '_call_button_button_text', 'field_62fd9b16f58b1'),
(1002, 93, 'call_button_phone_number', '8884809996'),
(1003, 93, '_call_button_phone_number', 'field_62fd9b46f58b2'),
(1004, 93, 'call_button', ''),
(1005, 93, '_call_button', 'field_62fd9aecf58b0'),
(1006, 93, 'benefits_0_benefit_icon', 'fa-dollar-sign'),
(1007, 93, '_benefits_0_benefit_icon', 'field_62fd9e78a1fb1'),
(1008, 93, 'benefits_0_benefit_text', 'Best Prices'),
(1009, 93, '_benefits_0_benefit_text', 'field_62fd9ebca1fb2'),
(1010, 93, 'benefits_1_benefit_icon', 'fa-award') ;
INSERT INTO `it_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1011, 93, '_benefits_1_benefit_icon', 'field_62fd9e78a1fb1'),
(1012, 93, 'benefits_1_benefit_text', 'Best Guarantiees'),
(1013, 93, '_benefits_1_benefit_text', 'field_62fd9ebca1fb2'),
(1014, 93, 'benefits_2_benefit_icon', 'fa-headphones-simple'),
(1015, 93, '_benefits_2_benefit_icon', 'field_62fd9e78a1fb1'),
(1016, 93, 'benefits_2_benefit_text', 'Best Customer Service'),
(1017, 93, '_benefits_2_benefit_text', 'field_62fd9ebca1fb2'),
(1018, 93, 'benefits_3_benefit_icon', 'fa-gear'),
(1019, 93, '_benefits_3_benefit_icon', 'field_62fd9e78a1fb1'),
(1020, 93, 'benefits_3_benefit_text', 'Best Trained technicians'),
(1021, 93, '_benefits_3_benefit_text', 'field_62fd9ebca1fb2'),
(1022, 93, 'benefits', '4'),
(1023, 93, '_benefits', 'field_62fd9e66a1fb0'),
(1024, 93, 'services_section_title', 'Our Services'),
(1025, 93, '_services_section_title', 'field_62fda97098207'),
(1026, 93, 'services_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex fugit laborum unde dolorem perferendis magni blanditiis dolor perspiciatis nesciunt aut facilis reprehenderit ea corrupti sunt, accusamus commodi, aliquid officiis rem.'),
(1027, 93, '_services_section_text', 'field_62fda9b498208'),
(1028, 93, 'services', '6'),
(1029, 93, '_services', 'field_62fda9ea98209'),
(1030, 93, 'services_0_service_image', '13'),
(1031, 93, '_services_0_service_image', 'field_62fdaa219820a'),
(1032, 93, 'services_0_service_name', 'MRI/MRA'),
(1033, 93, '_services_0_service_name', 'field_62fdaa739820b'),
(1034, 93, 'services_1_service_image', '13'),
(1035, 93, '_services_1_service_image', 'field_62fdaa219820a'),
(1036, 93, 'services_1_service_name', 'OPEN MRI'),
(1037, 93, '_services_1_service_name', 'field_62fdaa739820b'),
(1038, 93, 'services_2_service_image', '13'),
(1039, 93, '_services_2_service_image', 'field_62fdaa219820a'),
(1040, 93, 'services_2_service_name', 'MUSKULOSKELETAL'),
(1041, 93, '_services_2_service_name', 'field_62fdaa739820b'),
(1042, 93, 'services_3_service_image', '13'),
(1043, 93, '_services_3_service_image', 'field_62fdaa219820a'),
(1044, 93, 'services_3_service_name', 'NEURO'),
(1045, 93, '_services_3_service_name', 'field_62fdaa739820b'),
(1046, 93, 'services_4_service_image', '13'),
(1047, 93, '_services_4_service_image', 'field_62fdaa219820a'),
(1048, 93, 'services_4_service_name', 'SPINE'),
(1049, 93, '_services_4_service_name', 'field_62fdaa739820b'),
(1050, 93, 'services_5_service_image', '13'),
(1051, 93, '_services_5_service_image', 'field_62fdaa219820a'),
(1052, 93, 'services_5_service_name', 'BODY'),
(1053, 93, '_services_5_service_name', 'field_62fdaa739820b'),
(1054, 93, 'contact_section_text', 'Schedule online now!'),
(1055, 93, '_contact_section_text', 'field_62fdaee4f175a'),
(1056, 93, 'contact_phone_phone_text', '(888) 780-9996'),
(1057, 93, '_contact_phone_phone_text', 'field_62fdaf27f175c'),
(1058, 93, 'contact_phone_phone_number', '8887809996'),
(1059, 93, '_contact_phone_phone_number', 'field_62fdaf34f175d'),
(1060, 93, 'contact_phone', ''),
(1061, 93, '_contact_phone', 'field_62fdaefbf175b'),
(1062, 93, 'email_button_button_text', 'Email Us Today !'),
(1063, 93, '_email_button_button_text', 'field_62fdafe0f175f'),
(1064, 93, 'email_button_button_link', 'https://isning.com/'),
(1065, 93, '_email_button_button_link', 'field_62fdafeef1760'),
(1066, 93, 'email_button', ''),
(1067, 93, '_email_button', 'field_62fdaf4cf175e'),
(1068, 93, 'testimonials_section_title', 'Testimonials'),
(1069, 93, '_testimonials_section_title', 'field_62fdb67e5cdd5'),
(1070, 93, 'testimonials_section_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, labore aspernatur? Expedita a cumque earum doloremque explicabo, sit natus id? Id ipsam totam repudiandae quasi placeat fugit mollitia itaque iure.'),
(1071, 93, '_testimonials_section_text', 'field_62fdb6b35cdd6'),
(1072, 93, 'testimonials_0_testimonial_video', 'Z3xkHmC-KQE'),
(1073, 93, '_testimonials_0_testimonial_video', 'field_62fdba076cddc'),
(1074, 93, 'testimonials_0_testimonial_picture', '14'),
(1075, 93, '_testimonials_0_testimonial_picture', 'field_62fdb9bfc6f9d'),
(1076, 93, 'testimonials_0_testimonial_name', 'Tina Martin'),
(1077, 93, '_testimonials_0_testimonial_name', 'field_62fdb9d1c6f9e'),
(1078, 93, 'testimonials_0_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!'),
(1079, 93, '_testimonials_0_testimonial_text', 'field_62fdb9e0c6f9f'),
(1080, 93, 'testimonials_1_testimonial_video', 'nam90gorcPs'),
(1081, 93, '_testimonials_1_testimonial_video', 'field_62fdba076cddc'),
(1082, 93, 'testimonials_1_testimonial_picture', '14'),
(1083, 93, '_testimonials_1_testimonial_picture', 'field_62fdb9bfc6f9d'),
(1084, 93, 'testimonials_1_testimonial_name', 'Tyna Martin'),
(1085, 93, '_testimonials_1_testimonial_name', 'field_62fdb9d1c6f9e'),
(1086, 93, 'testimonials_1_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(1087, 93, '_testimonials_1_testimonial_text', 'field_62fdb9e0c6f9f'),
(1088, 93, 'testimonials_2_testimonial_video', 'x2D7jHfitzk'),
(1089, 93, '_testimonials_2_testimonial_video', 'field_62fdba076cddc'),
(1090, 93, 'testimonials_2_testimonial_picture', '14'),
(1091, 93, '_testimonials_2_testimonial_picture', 'field_62fdb9bfc6f9d'),
(1092, 93, 'testimonials_2_testimonial_name', 'Martins Tina'),
(1093, 93, '_testimonials_2_testimonial_name', 'field_62fdb9d1c6f9e'),
(1094, 93, 'testimonials_2_testimonial_text', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis iusto, reiciendis ipsam facere a qui fuga rem veritatis voluptatem, saepe ullam incidunt hic laudantium harum officia sit!!'),
(1095, 93, '_testimonials_2_testimonial_text', 'field_62fdb9e0c6f9f'),
(1096, 93, 'testimonials', '3'),
(1097, 93, '_testimonials', 'field_62fdb99ac6f9c') ;

#
# End of data contents of table `it_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `it_posts`
#

DROP TABLE IF EXISTS `it_posts`;


#
# Table structure of table `it_posts`
#

CREATE TABLE `it_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_posts`
#
INSERT INTO `it_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-08-14 02:32:59', '2022-08-14 02:32:59', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-08-14 02:32:59', '2022-08-14 02:32:59', '', 0, 'http://localhost/isning/?p=1', 0, 'post', '', 1),
(2, 1, '2022-08-14 02:32:59', '2022-08-14 02:32:59', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/isning/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-08-14 02:32:59', '2022-08-14 02:32:59', '', 0, 'http://localhost/isning/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-08-14 02:32:59', '2022-08-14 02:32:59', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/isning.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-08-14 02:32:59', '2022-08-14 02:32:59', '', 0, 'http://localhost/isning/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-08-14 02:33:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-14 02:33:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/isning/?p=4', 0, 'post', '', 0),
(6, 1, '2022-08-14 03:06:53', '2022-08-14 03:06:53', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-08-18 05:11:59', '2022-08-18 05:11:59', '', 0, 'http://localhost/isning/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-08-14 03:06:36', '2022-08-14 03:06:36', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentytwo', '', '', '2022-08-14 03:06:36', '2022-08-14 03:06:36', '', 0, 'http://localhost/isning/2022/08/14/wp-global-styles-twentytwentytwo/', 0, 'wp_global_styles', '', 0),
(8, 1, '2022-08-14 03:06:53', '2022-08-14 03:06:53', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-14 03:06:53', '2022-08-14 03:06:53', '', 6, 'http://localhost/isning/?p=8', 0, 'revision', '', 0),
(9, 1, '2022-08-14 03:25:45', '2022-08-14 03:25:45', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-isning_theme', '', '', '2022-08-14 03:25:45', '2022-08-14 03:25:45', '', 0, 'http://localhost/isning/2022/08/14/wp-global-styles-isning_theme/', 0, 'wp_global_styles', '', 0),
(10, 1, '2022-08-14 03:38:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-08-14 03:38:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/isning/?post_type=acf-field-group&p=10', 0, 'acf-field-group', '', 0),
(11, 1, '2022-08-15 17:44:57', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-08-15 17:44:57', '0000-00-00 00:00:00', '', 0, 'http://localhost/isning/?post_type=acf-field-group&p=11', 0, 'acf-field-group', '', 0),
(13, 1, '2022-08-16 00:36:40', '2022-08-16 00:36:40', '', 'services', '', 'inherit', 'open', 'closed', '', 'services', '', '', '2022-08-18 03:03:22', '2022-08-18 03:03:22', '', 6, 'http://localhost/isning/wp-content/uploads/2022/08/services.webp', 0, 'attachment', 'image/webp', 0),
(14, 1, '2022-08-16 01:42:08', '2022-08-16 01:42:08', '', 'smile', '', 'inherit', 'open', 'closed', '', 'smile', '', '', '2022-08-18 04:06:01', '2022-08-18 04:06:01', '', 6, 'http://localhost/isning/wp-content/uploads/2022/08/smile.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2022-08-16 05:28:26', '2022-08-16 05:28:26', '', 'ct-scan', '', 'inherit', 'open', 'closed', '', 'ct-scan', '', '', '2022-08-16 05:28:26', '2022-08-16 05:28:26', '', 0, 'http://localhost/isning/wp-content/uploads/2022/08/ct-scan.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2022-08-16 05:40:17', '2022-08-16 05:40:17', '', 'new-ct', '', 'inherit', 'open', 'closed', '', 'new-ct', '', '', '2022-08-16 05:40:17', '2022-08-16 05:40:17', '', 0, 'http://localhost/isning/wp-content/uploads/2022/08/new-ct.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2022-08-16 05:45:19', '2022-08-16 05:45:19', '', 'ct-scan-2', '', 'inherit', 'open', 'closed', '', 'ct-scan-2', '', '', '2022-08-18 01:20:06', '2022-08-18 01:20:06', '', 6, 'http://localhost/isning/wp-content/uploads/2022/08/ct-scan-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'HOME', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2022-08-16 05:47:03', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-08-16 05:47:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/isning/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'ABOUT US', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'OUR SERVICES', '', 'publish', 'closed', 'closed', '', 'our-services', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=21', 3, 'nav_menu_item', '', 0),
(22, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'PROJECTS', '', 'publish', 'closed', 'closed', '', 'projects', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=22', 4, 'nav_menu_item', '', 0),
(23, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'TESTIMONIALS', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=23', 5, 'nav_menu_item', '', 0),
(24, 1, '2022-08-16 22:22:14', '2022-08-16 05:48:51', '', 'CONTACT US', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2022-08-16 22:22:14', '2022-08-16 22:22:14', '', 0, 'http://localhost/isning/?p=24', 6, 'nav_menu_item', '', 0),
(25, 1, '2022-08-17 03:12:03', '2022-08-17 03:12:03', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2022-08-17 03:12:03', '2022-08-17 03:12:03', '', 0, 'http://localhost/isning/wp-content/uploads/2022/08/logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2022-08-17 04:24:06', '2022-08-17 04:24:06', '', 'logo-dark', '', 'inherit', 'open', 'closed', '', 'logo-dark', '', '', '2022-08-17 04:24:06', '2022-08-17 04:24:06', '', 0, 'http://localhost/isning/wp-content/uploads/2022/08/logo-dark.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2022-08-17 04:24:08', '2022-08-17 04:24:08', '', 'logo-isning-dark', '', 'inherit', 'open', 'closed', '', 'logo-isning-dark', '', '', '2022-08-17 04:24:08', '2022-08-17 04:24:08', '', 0, 'http://localhost/isning/wp-content/uploads/2022/08/logo-isning-dark.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2022-08-17 21:57:43', '2022-08-17 21:57:43', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"6";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Test', 'test', 'publish', 'closed', 'closed', '', 'group_62fd6447ded7a', '', '', '2022-08-18 04:04:16', '2022-08-18 04:04:16', '', 0, 'http://localhost/isning/?post_type=acf-field-group&#038;p=28', 0, 'acf-field-group', '', 0),
(29, 1, '2022-08-17 22:00:47', '2022-08-17 22:00:47', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'banner', 'banner', 'publish', 'closed', 'closed', '', 'field_62fd646544773', '', '', '2022-08-17 22:00:47', '2022-08-17 22:00:47', '', 28, 'http://localhost/isning/?post_type=acf-field&p=29', 0, 'acf-field', '', 0),
(30, 1, '2022-08-17 22:00:47', '2022-08-17 22:00:47', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Background Image', 'background_image', 'publish', 'closed', 'closed', '', 'field_62fd648144774', '', '', '2022-08-18 01:33:19', '2022-08-18 01:33:19', '', 28, 'http://localhost/isning/?post_type=acf-field&#038;p=30', 1, 'acf-field', '', 0),
(31, 1, '2022-08-17 22:00:47', '2022-08-17 22:00:47', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Banner Title', 'banner_title', 'publish', 'closed', 'closed', '', 'field_62fd64db44775', '', '', '2022-08-17 22:00:47', '2022-08-17 22:00:47', '', 28, 'http://localhost/isning/?post_type=acf-field&p=31', 2, 'acf-field', '', 0),
(32, 1, '2022-08-17 22:00:47', '2022-08-17 22:00:47', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Banner Text', 'banner_text', 'publish', 'closed', 'closed', '', 'field_62fd64f944776', '', '', '2022-08-18 01:20:36', '2022-08-18 01:20:36', '', 28, 'http://localhost/isning/?post_type=acf-field&#038;p=32', 3, 'acf-field', '', 0),
(33, 1, '2022-08-18 01:20:06', '2022-08-18 01:20:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:20:06', '2022-08-18 01:20:06', '', 6, 'http://localhost/isning/?p=33', 0, 'revision', '', 0),
(34, 1, '2022-08-18 01:21:23', '2022-08-18 01:21:23', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:21:23', '2022-08-18 01:21:23', '', 6, 'http://localhost/isning/?p=34', 0, 'revision', '', 0),
(35, 1, '2022-08-18 01:27:02', '2022-08-18 01:27:02', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:27:02', '2022-08-18 01:27:02', '', 6, 'http://localhost/isning/?p=35', 0, 'revision', '', 0),
(36, 1, '2022-08-18 01:40:26', '2022-08-18 01:40:26', 'a:7:{s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Learn Button', 'learn_button', 'publish', 'closed', 'closed', '', 'field_62fd982ce32b1', '', '', '2022-08-18 01:40:26', '2022-08-18 01:40:26', '', 28, 'http://localhost/isning/?post_type=acf-field&p=36', 4, 'acf-field', '', 0),
(37, 1, '2022-08-18 01:40:26', '2022-08-18 01:40:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_62fd9855e32b2', '', '', '2022-08-18 01:40:26', '2022-08-18 01:40:26', '', 36, 'http://localhost/isning/?post_type=acf-field&p=37', 0, 'acf-field', '', 0),
(38, 1, '2022-08-18 01:40:26', '2022-08-18 01:40:26', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Button Link', 'button_link', 'publish', 'closed', 'closed', '', 'field_62fd9871e32b3', '', '', '2022-08-18 01:40:26', '2022-08-18 01:40:26', '', 36, 'http://localhost/isning/?post_type=acf-field&p=38', 1, 'acf-field', '', 0),
(39, 1, '2022-08-18 01:42:29', '2022-08-18 01:42:29', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:42:29', '2022-08-18 01:42:29', '', 6, 'http://localhost/isning/?p=39', 0, 'revision', '', 0),
(40, 1, '2022-08-18 01:53:12', '2022-08-18 01:53:12', 'a:7:{s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Call Button', 'call_button', 'publish', 'closed', 'closed', '', 'field_62fd9aecf58b0', '', '', '2022-08-18 01:53:12', '2022-08-18 01:53:12', '', 28, 'http://localhost/isning/?post_type=acf-field&p=40', 5, 'acf-field', '', 0),
(41, 1, '2022-08-18 01:53:12', '2022-08-18 01:53:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_62fd9b16f58b1', '', '', '2022-08-18 01:53:12', '2022-08-18 01:53:12', '', 40, 'http://localhost/isning/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 1, '2022-08-18 01:53:12', '2022-08-18 01:53:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Phone Number', 'phone_number', 'publish', 'closed', 'closed', '', 'field_62fd9b46f58b2', '', '', '2022-08-18 01:53:12', '2022-08-18 01:53:12', '', 40, 'http://localhost/isning/?post_type=acf-field&p=42', 1, 'acf-field', '', 0),
(43, 1, '2022-08-18 01:53:44', '2022-08-18 01:53:44', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:53:44', '2022-08-18 01:53:44', '', 6, 'http://localhost/isning/?p=43', 0, 'revision', '', 0),
(44, 1, '2022-08-18 01:54:43', '2022-08-18 01:54:43', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 01:54:43', '2022-08-18 01:54:43', '', 6, 'http://localhost/isning/?p=44', 0, 'revision', '', 0),
(45, 1, '2022-08-18 02:07:08', '2022-08-18 02:07:08', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Benefits Section', 'benefits_section', 'publish', 'closed', 'closed', '', 'field_62fd9e15a1faf', '', '', '2022-08-18 02:07:08', '2022-08-18 02:07:08', '', 28, 'http://localhost/isning/?post_type=acf-field&p=45', 6, 'acf-field', '', 0),
(46, 1, '2022-08-18 02:07:08', '2022-08-18 02:07:08', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Benefits', 'benefits', 'publish', 'closed', 'closed', '', 'field_62fd9e66a1fb0', '', '', '2022-08-18 02:07:08', '2022-08-18 02:07:08', '', 28, 'http://localhost/isning/?post_type=acf-field&p=46', 7, 'acf-field', '', 0),
(47, 1, '2022-08-18 02:07:08', '2022-08-18 02:07:08', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Benefit Icon', 'benefit_icon', 'publish', 'closed', 'closed', '', 'field_62fd9e78a1fb1', '', '', '2022-08-18 02:07:08', '2022-08-18 02:07:08', '', 46, 'http://localhost/isning/?post_type=acf-field&p=47', 0, 'acf-field', '', 0),
(48, 1, '2022-08-18 02:07:08', '2022-08-18 02:07:08', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Benefit Text', 'benefit_text', 'publish', 'closed', 'closed', '', 'field_62fd9ebca1fb2', '', '', '2022-08-18 02:07:08', '2022-08-18 02:07:08', '', 46, 'http://localhost/isning/?post_type=acf-field&p=48', 1, 'acf-field', '', 0),
(49, 1, '2022-08-18 02:13:23', '2022-08-18 02:13:23', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 02:13:23', '2022-08-18 02:13:23', '', 6, 'http://localhost/isning/?p=49', 0, 'revision', '', 0),
(50, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Services Section', 'services_section', 'publish', 'closed', 'closed', '', 'field_62fda93e98206', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 28, 'http://localhost/isning/?post_type=acf-field&p=50', 8, 'acf-field', '', 0),
(51, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Services Section Title', 'services_section_title', 'publish', 'closed', 'closed', '', 'field_62fda97098207', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 28, 'http://localhost/isning/?post_type=acf-field&p=51', 9, 'acf-field', '', 0),
(52, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Services Section Text', 'services_section_text', 'publish', 'closed', 'closed', '', 'field_62fda9b498208', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 28, 'http://localhost/isning/?post_type=acf-field&p=52', 10, 'acf-field', '', 0),
(53, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Services', 'services', 'publish', 'closed', 'closed', '', 'field_62fda9ea98209', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 28, 'http://localhost/isning/?post_type=acf-field&p=53', 11, 'acf-field', '', 0),
(54, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Service Image', 'service_image', 'publish', 'closed', 'closed', '', 'field_62fdaa219820a', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 53, 'http://localhost/isning/?post_type=acf-field&p=54', 0, 'acf-field', '', 0),
(55, 1, '2022-08-18 02:57:32', '2022-08-18 02:57:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Service Name', 'service_name', 'publish', 'closed', 'closed', '', 'field_62fdaa739820b', '', '', '2022-08-18 02:57:32', '2022-08-18 02:57:32', '', 53, 'http://localhost/isning/?post_type=acf-field&p=55', 1, 'acf-field', '', 0),
(56, 1, '2022-08-18 03:00:10', '2022-08-18 03:00:10', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:00:10', '2022-08-18 03:00:10', '', 6, 'http://localhost/isning/?p=56', 0, 'revision', '', 0),
(57, 1, '2022-08-18 03:03:22', '2022-08-18 03:03:22', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:03:22', '2022-08-18 03:03:22', '', 6, 'http://localhost/isning/?p=57', 0, 'revision', '', 0),
(58, 1, '2022-08-18 03:06:03', '2022-08-18 03:06:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:06:03', '2022-08-18 03:06:03', '', 6, 'http://localhost/isning/?p=58', 0, 'revision', '', 0),
(59, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Contact Section', 'contact_section', 'publish', 'closed', 'closed', '', 'field_62fdaeabf1759', '', '', '2022-08-18 03:20:33', '2022-08-18 03:20:33', '', 28, 'http://localhost/isning/?post_type=acf-field&p=59', 12, 'acf-field', '', 0),
(60, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Section Text', 'contact_section_text', 'publish', 'closed', 'closed', '', 'field_62fdaee4f175a', '', '', '2022-08-18 03:29:41', '2022-08-18 03:29:41', '', 28, 'http://localhost/isning/?post_type=acf-field&#038;p=60', 13, 'acf-field', '', 0),
(61, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:7:{s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Contact Phone', 'contact_phone', 'publish', 'closed', 'closed', '', 'field_62fdaefbf175b', '', '', '2022-08-18 03:29:41', '2022-08-18 03:29:41', '', 28, 'http://localhost/isning/?post_type=acf-field&#038;p=61', 14, 'acf-field', '', 0),
(62, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Phone Text', 'phone_text', 'publish', 'closed', 'closed', '', 'field_62fdaf27f175c', '', '', '2022-08-18 03:20:33', '2022-08-18 03:20:33', '', 61, 'http://localhost/isning/?post_type=acf-field&p=62', 0, 'acf-field', '', 0),
(63, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Phone Number', 'phone_number', 'publish', 'closed', 'closed', '', 'field_62fdaf34f175d', '', '', '2022-08-18 03:20:33', '2022-08-18 03:20:33', '', 61, 'http://localhost/isning/?post_type=acf-field&p=63', 1, 'acf-field', '', 0),
(64, 1, '2022-08-18 03:20:33', '2022-08-18 03:20:33', 'a:7:{s:4:"type";s:5:"group";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"block";s:10:"sub_fields";a:0:{}}', 'Contact Email Button', 'email_button', 'publish', 'closed', 'closed', '', 'field_62fdaf4cf175e', '', '', '2022-08-18 03:29:41', '2022-08-18 03:29:41', '', 28, 'http://localhost/isning/?post_type=acf-field&#038;p=64', 15, 'acf-field', '', 0),
(65, 1, '2022-08-18 03:20:34', '2022-08-18 03:20:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_62fdafe0f175f', '', '', '2022-08-18 03:20:34', '2022-08-18 03:20:34', '', 64, 'http://localhost/isning/?post_type=acf-field&p=65', 0, 'acf-field', '', 0),
(66, 1, '2022-08-18 03:20:34', '2022-08-18 03:20:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Button Link', 'button_link', 'publish', 'closed', 'closed', '', 'field_62fdafeef1760', '', '', '2022-08-18 03:20:34', '2022-08-18 03:20:34', '', 64, 'http://localhost/isning/?post_type=acf-field&p=66', 1, 'acf-field', '', 0),
(68, 1, '2022-08-18 03:30:36', '2022-08-18 03:30:36', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:30:36', '2022-08-18 03:30:36', '', 6, 'http://localhost/isning/?p=68', 0, 'revision', '', 0),
(69, 1, '2022-08-18 03:50:14', '2022-08-18 03:50:14', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Testimonials Section', 'testimonials_section', 'publish', 'closed', 'closed', '', 'field_62fdb60d5cdd4', '', '', '2022-08-18 03:50:14', '2022-08-18 03:50:14', '', 28, 'http://localhost/isning/?post_type=acf-field&p=69', 16, 'acf-field', '', 0),
(70, 1, '2022-08-18 03:50:14', '2022-08-18 03:50:14', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Testimonials Section Title', 'testimonials_section_title', 'publish', 'closed', 'closed', '', 'field_62fdb67e5cdd5', '', '', '2022-08-18 03:50:14', '2022-08-18 03:50:14', '', 28, 'http://localhost/isning/?post_type=acf-field&p=70', 17, 'acf-field', '', 0),
(71, 1, '2022-08-18 03:50:14', '2022-08-18 03:50:14', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Testimonials Section text', 'testimonials_section_text', 'publish', 'closed', 'closed', '', 'field_62fdb6b35cdd6', '', '', '2022-08-18 03:50:14', '2022-08-18 03:50:14', '', 28, 'http://localhost/isning/?post_type=acf-field&p=71', 18, 'acf-field', '', 0),
(72, 1, '2022-08-18 03:51:08', '2022-08-18 03:51:08', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:51:08', '2022-08-18 03:51:08', '', 6, 'http://localhost/isning/?p=72', 0, 'revision', '', 0),
(73, 1, '2022-08-18 03:51:56', '2022-08-18 03:51:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 03:51:56', '2022-08-18 03:51:56', '', 6, 'http://localhost/isning/?p=73', 0, 'revision', '', 0),
(74, 1, '2022-08-18 04:03:06', '2022-08-18 04:03:06', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Testimonials', 'testimonials', 'publish', 'closed', 'closed', '', 'field_62fdb99ac6f9c', '', '', '2022-08-18 04:03:06', '2022-08-18 04:03:06', '', 28, 'http://localhost/isning/?post_type=acf-field&p=74', 19, 'acf-field', '', 0),
(75, 1, '2022-08-18 04:03:06', '2022-08-18 04:03:06', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Testimonial Picture', 'testimonial_picture', 'publish', 'closed', 'closed', '', 'field_62fdb9bfc6f9d', '', '', '2022-08-18 04:04:16', '2022-08-18 04:04:16', '', 74, 'http://localhost/isning/?post_type=acf-field&#038;p=75', 1, 'acf-field', '', 0),
(76, 1, '2022-08-18 04:03:06', '2022-08-18 04:03:06', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Testimonial Name', 'testimonial_name', 'publish', 'closed', 'closed', '', 'field_62fdb9d1c6f9e', '', '', '2022-08-18 04:04:16', '2022-08-18 04:04:16', '', 74, 'http://localhost/isning/?post_type=acf-field&#038;p=76', 2, 'acf-field', '', 0),
(77, 1, '2022-08-18 04:03:06', '2022-08-18 04:03:06', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Testimonial Text', 'testimonial_text', 'publish', 'closed', 'closed', '', 'field_62fdb9e0c6f9f', '', '', '2022-08-18 04:04:16', '2022-08-18 04:04:16', '', 74, 'http://localhost/isning/?post_type=acf-field&#038;p=77', 3, 'acf-field', '', 0),
(78, 1, '2022-08-18 04:04:16', '2022-08-18 04:04:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Testimonial Video', 'testimonial_video', 'publish', 'closed', 'closed', '', 'field_62fdba076cddc', '', '', '2022-08-18 04:04:16', '2022-08-18 04:04:16', '', 74, 'http://localhost/isning/?post_type=acf-field&p=78', 0, 'acf-field', '', 0),
(79, 1, '2022-08-18 04:06:01', '2022-08-18 04:06:01', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 04:06:01', '2022-08-18 04:06:01', '', 6, 'http://localhost/isning/?p=79', 0, 'revision', '', 0),
(80, 1, '2022-08-18 04:23:46', '2022-08-18 04:23:46', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 04:23:46', '2022-08-18 04:23:46', '', 6, 'http://localhost/isning/?p=80', 0, 'revision', '', 0),
(81, 1, '2022-08-18 04:27:10', '2022-08-18 04:27:10', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:18:"acf-options-footer";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Footer Settings', 'footer-settings', 'publish', 'closed', 'closed', '', 'group_62fdbf4f7061a', '', '', '2022-08-18 04:49:21', '2022-08-18 04:49:21', '', 0, 'http://localhost/isning/?post_type=acf-field-group&#038;p=81', 0, 'acf-field-group', '', 0),
(82, 1, '2022-08-18 04:29:48', '2022-08-18 04:29:48', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Sub Footer', 'sub_footer', 'publish', 'closed', 'closed', '', 'field_62fdbfee46970', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&#038;p=82', 3, 'acf-field', '', 0),
(83, 1, '2022-08-18 04:29:48', '2022-08-18 04:29:48', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Sub Footer Image', 'sub_footer_image', 'publish', 'closed', 'closed', '', 'field_62fdc01046971', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&#038;p=83', 4, 'acf-field', '', 0),
(84, 1, '2022-08-18 04:29:48', '2022-08-18 04:29:48', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Site Copyright', 'site_copyright', 'publish', 'closed', 'closed', '', 'field_62fdc02346972', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&#038;p=84', 5, 'acf-field', '', 0),
(85, 1, '2022-08-18 04:40:09', '2022-08-18 04:40:09', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer', 'footer', 'publish', 'closed', 'closed', '', 'field_62fdc22fcadff', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&p=85', 0, 'acf-field', '', 0),
(86, 1, '2022-08-18 04:40:09', '2022-08-18 04:40:09', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer Logo', 'footer_logo', 'publish', 'closed', 'closed', '', 'field_62fdc243cae00', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&p=86', 1, 'acf-field', '', 0),
(87, 1, '2022-08-18 04:40:09', '2022-08-18 04:40:09', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Footer Text', 'footer_text', 'publish', 'closed', 'closed', '', 'field_62fdc263cae01', '', '', '2022-08-18 04:40:09', '2022-08-18 04:40:09', '', 81, 'http://localhost/isning/?post_type=acf-field&p=87', 2, 'acf-field', '', 0),
(88, 1, '2022-08-18 04:52:22', '2022-08-18 04:52:22', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"theme-general-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Site Settings', 'site-settings', 'publish', 'closed', 'closed', '', 'group_62fdc5440d956', '', '', '2022-08-18 04:55:34', '2022-08-18 04:55:34', '', 0, 'http://localhost/isning/?post_type=acf-field-group&#038;p=88', 0, 'acf-field-group', '', 0),
(89, 1, '2022-08-18 04:52:22', '2022-08-18 04:52:22', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Site Logo', 'site_logo', 'publish', 'closed', 'closed', '', 'field_62fdc5514827f', '', '', '2022-08-18 04:52:22', '2022-08-18 04:52:22', '', 88, 'http://localhost/isning/?post_type=acf-field&p=89', 0, 'acf-field', '', 0),
(90, 1, '2022-08-18 04:55:34', '2022-08-18 04:55:34', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Open Hours', 'open_hours', 'publish', 'closed', 'closed', '', 'field_62fdc5eaf8c32', '', '', '2022-08-18 04:55:34', '2022-08-18 04:55:34', '', 88, 'http://localhost/isning/?post_type=acf-field&p=90', 1, 'acf-field', '', 0),
(91, 1, '2022-08-18 04:55:34', '2022-08-18 04:55:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Open Day', 'open_day', 'publish', 'closed', 'closed', '', 'field_62fdc61af8c33', '', '', '2022-08-18 04:55:34', '2022-08-18 04:55:34', '', 90, 'http://localhost/isning/?post_type=acf-field&p=91', 0, 'acf-field', '', 0),
(92, 1, '2022-08-18 04:55:34', '2022-08-18 04:55:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Open Hour', 'open_hour', 'publish', 'closed', 'closed', '', 'field_62fdc633f8c34', '', '', '2022-08-18 04:55:34', '2022-08-18 04:55:34', '', 90, 'http://localhost/isning/?post_type=acf-field&p=92', 1, 'acf-field', '', 0),
(93, 1, '2022-08-18 05:11:59', '2022-08-18 05:11:59', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-08-18 05:11:59', '2022-08-18 05:11:59', '', 6, 'http://localhost/isning/?p=93', 0, 'revision', '', 0) ;

#
# End of data contents of table `it_posts`
# --------------------------------------------------------



#
# Delete any existing table `it_smush_dir_images`
#

DROP TABLE IF EXISTS `it_smush_dir_images`;


#
# Table structure of table `it_smush_dir_images`
#

CREATE TABLE `it_smush_dir_images` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_hash` char(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lossy` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `error` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `file_time` int(10) unsigned DEFAULT NULL,
  `last_scan` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path_hash` (`path_hash`),
  KEY `image_size` (`image_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_smush_dir_images`
#

#
# End of data contents of table `it_smush_dir_images`
# --------------------------------------------------------



#
# Delete any existing table `it_term_relationships`
#

DROP TABLE IF EXISTS `it_term_relationships`;


#
# Table structure of table `it_term_relationships`
#

CREATE TABLE `it_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_term_relationships`
#
INSERT INTO `it_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(7, 2, 0),
(9, 3, 0),
(18, 4, 0),
(20, 4, 0),
(21, 4, 0),
(22, 4, 0),
(23, 4, 0),
(24, 4, 0) ;

#
# End of data contents of table `it_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `it_term_taxonomy`
#

DROP TABLE IF EXISTS `it_term_taxonomy`;


#
# Table structure of table `it_term_taxonomy`
#

CREATE TABLE `it_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_term_taxonomy`
#
INSERT INTO `it_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'wp_theme', '', 0, 1),
(4, 4, 'nav_menu', '', 0, 6) ;

#
# End of data contents of table `it_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `it_termmeta`
#

DROP TABLE IF EXISTS `it_termmeta`;


#
# Table structure of table `it_termmeta`
#

CREATE TABLE `it_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_termmeta`
#

#
# End of data contents of table `it_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `it_terms`
#

DROP TABLE IF EXISTS `it_terms`;


#
# Table structure of table `it_terms`
#

CREATE TABLE `it_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_terms`
#
INSERT INTO `it_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'twentytwentytwo', 'twentytwentytwo', 0),
(3, 'isning_theme', 'isning_theme', 0),
(4, 'sc_menu', 'sc_menu', 0) ;

#
# End of data contents of table `it_terms`
# --------------------------------------------------------



#
# Delete any existing table `it_usermeta`
#

DROP TABLE IF EXISTS `it_usermeta`;


#
# Table structure of table `it_usermeta`
#

CREATE TABLE `it_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_usermeta`
#
INSERT INTO `it_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'test_admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'it_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'it_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"112c5abbbdc2ea6e4f4a6ff4118ee21f04da4e24b6161284c7d493931cd7802c";a:4:{s:10:"expiration";i:1660792383;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:80:"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0";s:5:"login";i:1660619583;}s:64:"b3b96e6ed9dd912fad4ac6fe600885e4a07f768a839daee565a387d8ce49370e";a:4:{s:10:"expiration";i:1660859156;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36";s:5:"login";i:1660686356;}}'),
(17, 1, 'it_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'nav_menu_recently_edited', '4'),
(22, 1, 'it_user-settings', 'libraryContent=browse'),
(23, 1, 'it_user-settings-time', '1660785603') ;

#
# End of data contents of table `it_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `it_users`
#

DROP TABLE IF EXISTS `it_users`;


#
# Table structure of table `it_users`
#

CREATE TABLE `it_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `it_users`
#
INSERT INTO `it_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'test_admin', '$P$BLWV3bwct6JSHPRkhTbD0gDZEM42dG1', 'test_admin', 'jenniercruz90@gmail.com', 'http://localhost/isning', '2022-08-14 02:32:59', '', 0, 'test_admin') ;

#
# End of data contents of table `it_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

